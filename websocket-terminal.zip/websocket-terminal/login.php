<?php
session_start();

// ============================================
// CONFIGURATION - Change these credentials
// ============================================
define('AUTH_USERNAME', 'admin');
define('AUTH_PASSWORD', 'Webhook@2026');  // Change this!
// ============================================

$error = '';

// Already logged in?
if (isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true) {
    header('Location: udp_dashboard.php');
    exit;
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($username === AUTH_USERNAME && $password === AUTH_PASSWORD) {
        $_SESSION['authenticated'] = true;
        $_SESSION['login_time'] = time();
        $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
        
        // Redirect to intended page or dashboard
        $redirect = $_GET['redirect'] ?? 'udp_dashboard.php';
        $allowed = ['udp_dashboard.php', 'terminal.php', 'udp_api.php'];
        $base = basename(parse_url($redirect, PHP_URL_PATH));
        if (!in_array($base, $allowed)) {
            $redirect = 'udp_dashboard.php';
        }
        header('Location: ' . $redirect);
        exit;
    } else {
        $error = 'Invalid username or password';
    }
}

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login - Webhook System</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #0a0e12;
            color: #e1e4e8;
            font-family: 'SF Mono', 'Fira Code', 'Courier New', monospace;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .login-container {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 12px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.4);
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header .icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        .login-header h1 {
            color: #58a6ff;
            font-size: 22px;
            margin-bottom: 5px;
        }
        .login-header p {
            color: #8b949e;
            font-size: 13px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            color: #8b949e;
            font-size: 12px;
            margin-bottom: 6px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .form-group input {
            width: 100%;
            background: #0d1117;
            border: 1px solid #30363d;
            color: #e1e4e8;
            padding: 12px 15px;
            border-radius: 8px;
            font-family: inherit;
            font-size: 14px;
            transition: border-color 0.2s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #58a6ff;
        }
        .btn-login {
            width: 100%;
            background: #238636;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-family: inherit;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        .btn-login:hover {
            background: #2ea043;
        }
        .error {
            background: #f8514920;
            border: 1px solid #f85149;
            color: #f85149;
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 13px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="icon">🔐</div>
            <h1>Webhook System</h1>
            <p>Authentication required</p>
        </div>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" autocomplete="username" autofocus required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" autocomplete="current-password" required>
            </div>
            <button type="submit" class="btn-login">🔓 Login</button>
        </form>
    </div>
</body>
</html>