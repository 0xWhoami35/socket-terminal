<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: login.php?redirect=terminal.php?' . $_SERVER['QUERY_STRING']);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Webhook Terminal</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: #0a0a0a;
            color: #00ff00;
            font-family: 'Courier New', monospace;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* Header */
        .header {
            background: #1a1a1a;
            padding: 12px 20px;
            border-bottom: 2px solid #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .title {
            color: #00ff00;
            font-size: 16px;
            font-weight: bold;
        }
        
        .status {
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .status.connected {
            background: #00ff00;
            color: #000;
        }
        
        .status.disconnected {
            background: #ff0000;
            color: #fff;
        }
        
        /* Agent Info Panel */
        .agent-panel {
            background: #1a1a1a;
            padding: 15px 20px;
            border-bottom: 1px solid #333;
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .agent-panel label {
            color: #888;
            font-size: 12px;
        }
        
        .agent-panel input {
            background: #000;
            border: 1px solid #333;
            color: #00ff00;
            padding: 8px 12px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            border-radius: 4px;
            width: 350px;
        }
        
        .agent-panel input:focus {
            outline: none;
            border-color: #00ff00;
        }
        
        .agent-panel button {
            background: #00ff00;
            color: #000;
            border: none;
            padding: 8px 16px;
            font-family: 'Courier New', monospace;
            font-weight: bold;
            cursor: pointer;
            border-radius: 4px;
            font-size: 13px;
        }
        
        .agent-panel button:hover {
            background: #00cc00;
        }
        
        .agent-panel button.secondary {
            background: #333;
            color: #fff;
        }
        
        .agent-panel button.secondary:hover {
            background: #444;
        }
        
        /* Terminal Output */
        .terminal {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #0a0a0a;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            line-height: 1.5;
        }
        
        .line {
            margin: 4px 0;
            white-space: pre-wrap;
            word-wrap: break-word;
            animation: fadeIn 0.2s;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(2px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .prompt {
            color: #00ff00;
            font-weight: bold;
            margin-right: 10px;
        }
        
        .command {
            color: #ffff00;
        }
        
        .output {
            color: #ffffff;
            margin-left: 25px;
            padding-left: 15px;
            border-left: 2px solid #333;
            margin-top: 5px;
            margin-bottom: 5px;
        }
        
        .system {
            color: #00ffff;
        }
        
        .error {
            color: #ff5555;
        }
        
        .success {
            color: #00ff00;
        }
        
        .timestamp {
            color: #666;
            font-size: 11px;
            margin-left: 10px;
        }
        
        /* Input Area */
        .input-area {
            background: #1a1a1a;
            padding: 15px 20px;
            border-top: 2px solid #333;
            display: flex;
            gap: 10px;
        }
        
        .input-area input {
            flex: 1;
            background: #000;
            border: 1px solid #333;
            color: #00ff00;
            padding: 12px 15px;
            font-family: 'Courier New', monospace;
            font-size: 15px;
            border-radius: 4px;
        }
        
        .input-area input:focus {
            outline: none;
            border-color: #00ff00;
        }
        
        .input-area input:disabled {
            background: #222;
            color: #666;
            border-color: #333;
        }
        
        .input-area button {
            background: #00ff00;
            color: #000;
            border: none;
            padding: 12px 25px;
            font-family: 'Courier New', monospace;
            font-weight: bold;
            cursor: pointer;
            border-radius: 4px;
            font-size: 15px;
        }
        
        .input-area button:hover:not(:disabled) {
            background: #00cc00;
        }
        
        .input-area button:disabled {
            background: #333;
            color: #666;
            cursor: not-allowed;
        }
        
        /* Quick Commands */
        .quick-commands {
            background: #1a1a1a;
            padding: 10px 20px;
            border-top: 1px solid #333;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .quick-btn {
            background: #333;
            color: #fff;
            border: none;
            padding: 6px 12px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            cursor: pointer;
            border-radius: 3px;
        }
        
        .quick-btn:hover {
            background: #444;
        }
        
        /* Loading Spinner */
        .spinner {
            display: inline-block;
            width: 12px;
            height: 12px;
            border: 2px solid #00ff00;
            border-radius: 50%;
            border-top-color: transparent;
            animation: spin 1s linear infinite;
            margin-right: 5px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Welcome Banner */
        .banner {
            color: #00ff00;
            margin-bottom: 20px;
            line-height: 1.4;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">🚀 Webhook Terminal v2.0</div>
        <div class="status disconnected" id="status">● DISCONNECTED</div>
    </div>
    
    <div class="agent-panel">
        <label>🔑 Agent ID / Secret Key:</label>
        <input type="text" id="agentId" placeholder="Enter your agent ID" value="">
        <button onclick="connect()" id="connectBtn">🔌 Connect</button>
        <button onclick="disconnect()" id="disconnectBtn" style="display: none;" class="secondary">🔌 Disconnect</button>
        <button onclick="generateKey()" class="secondary">✨ Generate New Key</button>
        <button onclick="clearTerminal()" class="secondary">🧹 Clear</button>
    </div>
    
    <div class="terminal" id="terminal">
        <div class="banner">
            ╔══════════════════════════════════════╗<br>
            ║   🔐 Webhook Terminal System         ║<br>
            ║   Enter your Agent ID and click      ║<br>
            ║   Connect to start sending commands  ║<br>
            ╚══════════════════════════════════════╝
        </div>
    </div>
    
    <div class="quick-commands">
        <button class="quick-btn" onclick="quickCommand('whoami')">whoami</button>
        <button class="quick-btn" onclick="quickCommand('ipconfig')">ipconfig</button>
        <button class="quick-btn" onclick="quickCommand('ls')">ls</button>
        <button class="quick-btn" onclick="quickCommand('pwd')">pwd</button>
        <button class="quick-btn" onclick="quickCommand('date')">date</button>
        <button class="quick-btn" onclick="quickCommand('hostname')">hostname</button>
        <button class="quick-btn" onclick="quickCommand('echo hello')">echo</button>
    </div>
    
    <div class="input-area">
        <input type="text" id="commandInput" placeholder="Enter command..." disabled>
        <button onclick="sendCommand()" id="sendBtn" disabled>Send</button>
    </div>

    <script>
        // Configuration
        const API_URL = 'http://furbyco.com/webhook/udp_api.php';
        let agentId = '';
        let connected = false;
        let pollingInterval = null;
        // Terminal state
        let DEBUG = false;
        
        // DOM Elements
        const terminal = document.getElementById('terminal');
        const commandInput = document.getElementById('commandInput');
        const sendBtn = document.getElementById('sendBtn');
        const connectBtn = document.getElementById('connectBtn');
        const disconnectBtn = document.getElementById('disconnectBtn');
        const statusDiv = document.getElementById('status');
        const agentIdInput = document.getElementById('agentId');
        
        // Load saved agent ID - URL param takes priority
        const urlParams = new URLSearchParams(window.location.search);
        const urlAgentId = urlParams.get('agent');
        const savedAgentId = urlAgentId || localStorage.getItem('webhook_agent_id');
        if (savedAgentId) {
            agentIdInput.value = savedAgentId;
        }
        
        // Add line to terminal
        function addLine(type, content) {
            const line = document.createElement('div');
            line.className = 'line';
            
            const now = new Date();
            const timestamp = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}:${now.getSeconds().toString().padStart(2,'0')}`;
            
            let html = '';
            
            switch(type) {
                case 'command':
                    html = `<span class="prompt">$</span> <span class="command">${escapeHtml(content)}</span> <span class="timestamp">[${timestamp}]</span>`;
                    break;
                case 'output':
                    html = `<div class="output">${escapeHtml(content)}</div> <span class="timestamp">[${timestamp}]</span>`;
                    break;
                case 'system':
                    html = `<span class="system">[${timestamp}]</span> <span class="system">${escapeHtml(content)}</span>`;
                    break;
                case 'success':
                    html = `<span class="success">[${timestamp}]</span> <span class="success">✓ ${escapeHtml(content)}</span>`;
                    break;
                case 'error':
                    html = `<span class="error">[${timestamp}]</span> <span class="error">❌ ${escapeHtml(content)}</span>`;
                    break;
                default:
                    html = `<span>[${timestamp}]</span> ${escapeHtml(content)}`;
            }
            
            line.innerHTML = html;
            terminal.appendChild(line);
            
            // Auto-scroll to bottom
            terminal.scrollTop = terminal.scrollHeight;
        }
        
        // Escape HTML special characters
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // Connect to agent
        function connect() {
            agentId = agentIdInput.value.trim();
            
            if (!agentId) {
                addLine('error', 'Please enter an Agent ID');
                return;
            }
            
            // Save to localStorage
            localStorage.setItem('webhook_agent_id', agentId);
            
            // Update UI
            connected = true;
            commandInput.disabled = false;
            sendBtn.disabled = false;
            agentIdInput.disabled = true;
            connectBtn.style.display = 'none';
            disconnectBtn.style.display = 'inline-block';
            statusDiv.className = 'status connected';
            statusDiv.innerHTML = '● CONNECTED';
            
            addLine('success', `Connected to agent: ${agentId}`);
            addLine('system', 'Ready to accept commands. Type "help" for available commands.');
            
            // Start polling for results
            startPolling();
            
            // Load recent results
            loadResults();
        }
        
        // Disconnect
        function disconnect() {
            connected = false;
            commandInput.disabled = true;
            sendBtn.disabled = true;
            agentIdInput.disabled = false;
            connectBtn.style.display = 'inline-block';
            disconnectBtn.style.display = 'none';
            statusDiv.className = 'status disconnected';
            statusDiv.innerHTML = '● DISCONNECTED';
            
            if (pollingInterval) {
                clearInterval(pollingInterval);
                pollingInterval = null;
            }
            
            addLine('system', 'Disconnected from agent');
        }
        
        // Start polling for results
        function startPolling() {
            if (pollingInterval) {
                clearInterval(pollingInterval);
            }
            
            pollingInterval = setInterval(() => {
                if (connected) {
                    loadResults();
                }
            }, 1500); // Poll every 1.5 seconds
        }
        
        // Load results from API — match by unique markers
        function loadResults() {
            if (pendingMarkers.size === 0) return;

            const url = `${API_URL}?action=get_results&agent_id=${encodeURIComponent(agentId)}&limit=50`;
            
            fetch(url)
                .then(response => response.json())
                .then(results => {
                    if (!Array.isArray(results)) return;

                    // Check each pending marker against results
                    for (const [marker, info] of pendingMarkers) {
                        for (let i = results.length - 1; i >= 0; i--) {
                            if (results[i].output && results[i].output.includes(marker)) {
                                // Found it — strip marker and display
                                const output = results[i].output
                                    .replace(marker, '')
                                    .replace(/\n$/, '');
                                addLine('output', output || '(empty output)');
                                pendingMarkers.delete(marker);
                                break;
                            }
                        }

                        // Timeout after 30s
                        if (pendingMarkers.has(marker)) {
                            info.elapsed += 1500;
                            if (info.elapsed > 30000) {
                                addLine('error', `⏱ Timeout waiting for: ${info.command}`);
                                pendingMarkers.delete(marker);
                            }
                        }
                    }
                })
                .catch(error => {
                    console.error('Poll error:', error);
                });
        }
        
        // Pending command markers waiting for results
        let pendingMarkers = new Map(); // marker => {command, elapsed}

        function sendCommand() {
            if (!connected) {
                addLine('error', 'Not connected. Click Connect first.');
                return;
            }
            
            const command = commandInput.value.trim();
            
            if (!command) {
                return;
            }
            
            // Handle special commands
            if (command === 'help') {
                showHelp();
                commandInput.value = '';
                return;
            }
            
            if (command === 'clear') {
                clearTerminal();
                commandInput.value = '';
                return;
            }
            
            if (command === 'exit') {
                disconnect();
                commandInput.value = '';
                return;
            }
            
            // Add command to terminal
            addLine('command', command);
            
            // Clear input
            commandInput.value = '';
            
            // Generate unique marker
            const marker = 'TM_' + Date.now() + '_' + Math.random().toString(36).substr(2,6);
            const wrappedCmd = command + '; echo "' + marker + '"';
            
            // Disable send button temporarily
            sendBtn.disabled = true;
            sendBtn.innerHTML = '<span class="spinner"></span> Sending';
            
            // Send via API
            const formData = new FormData();
            formData.append('action', 'send_command');
            formData.append('agent_id', agentId);
            formData.append('command', wrappedCmd);
            
            fetch(API_URL, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    addLine('system', '✅ Command queued. Waiting for execution...');
                    pendingMarkers.set(marker, { command, elapsed: 0 });
                } else {
                    addLine('error', data.error || 'Failed to queue command');
                }
            })
            .catch(error => {
                addLine('error', `Failed to queue command: ${error.message}`);
                console.error('Send error:', error);
            })
            .finally(() => {
                sendBtn.disabled = false;
                sendBtn.innerHTML = 'Send';
            });
        }
        
        // Quick command
        function quickCommand(cmd) {
            if (!connected) {
                addLine('error', 'Not connected. Click Connect first.');
                return;
            }
            commandInput.value = cmd;
            sendCommand();
        }
        
        // Show help
        function showHelp() {
            addLine('output', `
Available commands:
  help     - Show this help message
  clear    - Clear terminal
  exit     - Disconnect from agent
  whoami   - Show current user
  ipconfig - Show network config (Windows)
  ls       - List files (Linux/Mac)
  pwd      - Show current directory
  date     - Show current date/time
  Any other command will be executed on the agent
            `);
        }
        
        // Clear terminal
        function clearTerminal() {
            terminal.innerHTML = '';
            addLine('system', 'Terminal cleared');
        }
        
        // Generate new key
        function generateKey() {
            const name = prompt('Enter a name for this agent:', 'New Agent');
            if (!name) return;
            
            const formData = new FormData();
            formData.append('action', 'generate_key');
            formData.append('name', name);
            
            fetch(API_URL, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    agentIdInput.value = data.secret_key;
                    addLine('success', `Generated new secret key: ${data.secret_key}`);
                    addLine('system', 'Click Connect to use this agent');
                } else {
                    addLine('error', 'Failed to generate key');
                }
            })
            .catch(error => {
                addLine('error', `Error: ${error.message}`);
            });
        }
        
        // Handle Enter key
        commandInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && connected) {
                sendCommand();
            }
        });
        
        // Auto-connect if agent ID exists
        if (savedAgentId) {
            setTimeout(() => connect(), 500);
        }
        
        // Add welcome message
        addLine('system', 'Enter your Agent ID and click Connect to start');
    </script>
</body>
</html>