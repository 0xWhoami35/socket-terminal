iptables -I INPUT -p tcp --dport 7331 -j ACCEPT
service iptables save


cd /home/fcadmin/public_html/webhook
sudo -u fcadmin php relay.php &